// =============================================================================
// File: crc32_engine.v
// Module: crc32_engine
// Description: Parallel 32-bit CRC-32 (IEEE 802.3 standard) Hardware Accelerator
//              Polynomial: x^32 + x^26 + x^23 + x^22 + x^16 + x^12 + x^11 +
//                          x^10 + x^8 + x^7 + x^5 + x^4 + x^2 + x + 1
// =============================================================================

`timescale 1ns / 1ps

module crc32_engine (
    input  wire        clk,
    input  wire        resetn,
    
    // Control and Data
    input  wire        init,        // Load initial seed
    input  wire [31:0] seed,        // Custom seed (usually 32'hFFFFFFFF)
    input  wire        data_valid,  // Process word
    input  wire [31:0] data_in,     // Input 32-bit word
    
    // Checksum Output
    output wire [31:0] crc_out,     // Inverted final CRC result
    output reg  [31:0] crc_state    // Current running state
);

    assign crc_out = ~crc_state;

    // Parallel CRC32 combinational next-state function
    function [31:0] next_crc;
        input [31:0] d;
        input [31:0] c;
        reg [31:0] new_crc;
        integer i;
        begin
            new_crc = c ^ d;
            for (i = 0; i < 32; i = i + 1) begin
                if (new_crc[31]) begin
                    new_crc = (new_crc << 1) ^ 32'h04C11DB7;
                end else begin
                    new_crc = (new_crc << 1);
                end
            end
            next_crc = new_crc;
        end
    endfunction

    always @(posedge clk or negedge resetn) begin
        if (!resetn) begin
            crc_state <= 32'hFFFFFFFF;
        end else if (init) begin
            crc_state <= seed;
        end else if (data_valid) begin
            crc_state <= next_crc(data_in, crc_state);
        end
    end

endmodule
