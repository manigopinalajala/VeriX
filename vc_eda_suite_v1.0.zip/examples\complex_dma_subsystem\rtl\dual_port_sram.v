// =============================================================================
// File: dual_port_sram.v
// Module: dual_port_sram
// Description: Parameterized True Dual-Port Synchronous SRAM with byte write enables
//              and access collision detection logic.
// =============================================================================

`timescale 1ns / 1ps

module dual_port_sram #(
    parameter DATA_WIDTH = 32,
    parameter ADDR_WIDTH = 8     // 256 words = 1024 Bytes
)(
    // Port A Interface
    input  wire                  clk_a,
    input  wire                  en_a,
    input  wire [3:0]            we_a,       // Byte write enable [3:0]
    input  wire [ADDR_WIDTH-1:0] addr_a,
    input  wire [DATA_WIDTH-1:0] din_a,
    output reg  [DATA_WIDTH-1:0] dout_a,
    
    // Port B Interface
    input  wire                  clk_b,
    input  wire                  en_b,
    input  wire [3:0]            we_b,       // Byte write enable [3:0]
    input  wire [ADDR_WIDTH-1:0] addr_b,
    input  wire [DATA_WIDTH-1:0] din_b,
    output reg  [DATA_WIDTH-1:0] dout_b,
    
    // Conflict Detection
    output wire                  collision_warn
);

    localparam DEPTH = 1 << ADDR_WIDTH;

    // Memory array
    reg [DATA_WIDTH-1:0] mem [0:DEPTH-1];

    // Detect if both ports attempt to write to the exact same address concurrently
    assign collision_warn = (en_a && en_b && (|we_a) && (|we_b) && (addr_a == addr_b));

    // Port A Read / Write with Byte Strobing
    always @(posedge clk_a) begin
        if (en_a) begin
            if (we_a[0]) mem[addr_a][7:0]   <= din_a[7:0];
            if (we_a[1]) mem[addr_a][15:8]  <= din_a[15:8];
            if (we_a[2]) mem[addr_a][23:16] <= din_a[23:16];
            if (we_a[3]) mem[addr_a][31:24] <= din_a[31:24];
            dout_a <= mem[addr_a];
        end
    end

    // Port B Read / Write with Byte Strobing
    always @(posedge clk_b) begin
        if (en_b) begin
            if (we_b[0]) mem[addr_b][7:0]   <= din_b[7:0];
            if (we_b[1]) mem[addr_b][15:8]  <= din_b[15:8];
            if (we_b[2]) mem[addr_b][23:16] <= din_b[23:16];
            if (we_b[3]) mem[addr_b][31:24] <= din_b[31:24];
            dout_b <= mem[addr_b];
        end
    end

endmodule
