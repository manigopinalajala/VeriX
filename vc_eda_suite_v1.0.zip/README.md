# VC_SIM & VC_WAVE EDA STUDIO v1.0
### Enterprise-Grade Native SystemVerilog/UVM Simulator & Standalone Waveform Debugger

![VC_WAVE Studio](https://img.shields.io/badge/EDA-VC__WAVE%20Studio-blue.svg)
![VC_SIM Engine](https://img.shields.io/badge/Simulation-VC__SIM%20Native-brightgreen.svg)
![Platform](https://img.shields.io/badge/Platform-Windows%20%7C%20Linux%20%7C%20WSL-orange.svg)
![License](https://img.shields.io/badge/License-Proprietary%20%2F%20Open%20Architecture-purple.svg)

---

## 🌟 Executive Overview

**VC_SIM & VC_WAVE EDA Suite** is an advanced, standalone hardware verification and debugging platform designed for ASIC/FPGA digital design and verification engineers.

It combines:
1. **`vc_sim`**: A native C++ compiled simulation kernel supporting SystemVerilog, UVM 1.2 testbenches, and standard IEEE 1364 waveform dumping.
2. **`vc_wave`** *(formerly Verdi)*: A high-performance, standalone desktop GUI application for digital waveform exploration (`nWave`) and synchronized RTL source code navigation (`nTrace`).

---

## 🚀 Key Innovations

### 1. Unified Waveform + Embedded RTL Snapshot (Zero-Prompt Workflow)
Traditional EDA flows require opening a waveform file (`.vcd` / `.fsdb`) and then separately configuring filelists or browsing directories to load the matching RTL source files.

In **VC_SIM**:
* When `vc_sim` compiles and simulates your design, it captures an exact in-memory snapshot of all active RTL source code files from `filelist.f`.
* The complete RTL snapshot is automatically embedded directly inside the `.vcd` file using standard IEEE 1364 `$comment [VC_WAVE_RTL_SNAPSHOT_BEGIN] ... [VC_WAVE_RTL_SNAPSHOT_END] $end` encapsulation.
* Opening the `.vcd` file in **`vc_wave`** instantly unpacks the waveforms **and** all corresponding RTL modules, hierarchy, ports, and driver cone relationships. **You will never be prompted or asked again to locate RTL files.**

### 2. Standalone Native Desktop Application
* Runs directly on Windows and Linux/WSL as a native desktop window (no web browsers, no local webservers, zero latency).
* Bundled with its own standalone executable runtime on Windows (`vc_wave.exe`) — no Python or third-party packages need to be pre-installed!

### 3. Comprehensive Verification Debug Features
* **Split-Screen nTrace + nWave**: Side-by-side synchronized code inspection and digital timing waveforms.
* **🎯 Driver Backtracing (`Ctrl+D`)**: Jump directly to the exact line in RTL that actively drove a selected net or register.
* **⏩ Load Fanout Tracing (`Ctrl+L`)**: Follow where signals branch into combinational gates and downstream logic.
* **⚡ Cone of Influence / Drivers List**: View all driving signals in a dedicated analysis panel.
* **🟢 Live In-Line Signal Value Annotation**: Annotated live logic values displayed directly inside the RTL source code matching the primary waveform cursor ($C_1$).
* **📏 Dual Interactive Cursors ($C_1$ & $C_2$)**: Instant delta time ($\Delta$) and frequency measurement with bus radix switching (HEX, BIN, DEC).
* **⬆️ Up Scope & ⬇️ Down Scope Navigation**: Seamlessly traverse complex multi-level design hierarchies.

---

## 📁 Package Contents

```
vc_eda_suite_v1.0/
├── bin/                        # Pre-compiled executables and launchers
│   ├── vc_sim.exe              # Windows simulation engine compiler
│   ├── vc_sim                  # Linux simulation engine compiler
│   ├── vc_wave.exe             # Windows standalone native GUI debugger (10 MB)
│   ├── vc_wave.cmd / .bat      # Windows command launchers
│   ├── vc_wave                 # Linux / WSL shell launcher
│   └── verdi.cmd / .bat / verdi# Backward-compatibility alias wrappers
├── include/                    # Simulation kernel, UVM 1.2 & PLI headers
│   ├── sim_kernel.hpp          # Event-driven engine with auto-snapshot VCD dumper
│   ├── uvm_pkg.hpp             # UVM 1.2 class hierarchy runtime
│   ├── coverage_engine.hpp     # Functional coverage and UCDB reporting
│   └── vcs_api.hpp             # Compatibility interfaces
├── vc_wave/                    # VC_Wave source implementation
│   └── vc_wave_gui.py          # Python/Tkinter studio core
├── examples/                   # Verification examples
│   └── complex_dma_subsystem/  # Multi-module DMA + AXI4-Lite SoC subsystem
├── install_windows.bat         # 1-Click Windows installer
├── install_windows.ps1         # PowerShell installer
├── uninstall_windows.bat       # Windows uninstaller
├── install_linux.sh            # Linux / WSL installer
├── INSTALL.md                  # Detailed installation & configuration guide
├── QUICKSTART.md               # Quickstart verification tutorial
└── README.md                   # This overview
```

---

## ⚡ Quick Test

Once installed (see [INSTALL.md](INSTALL.md)), test the suite with the included DMA SoC example:

```bash
# Windows Command Prompt or PowerShell:
cd examples\complex_dma_subsystem
vc_wave dma_subsystem.vcd

# Linux or WSL:
cd examples/complex_dma_subsystem
vc_wave dma_subsystem.vcd
```
