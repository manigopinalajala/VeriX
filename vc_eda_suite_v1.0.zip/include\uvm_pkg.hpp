#ifndef UVM_PKG_HPP
#define UVM_PKG_HPP

#include "sim_kernel.hpp"
#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <string>
#include <vector>
#include <map>
#include <memory>
#include <functional>
#include <any>
#include <regex>
#include <set>
#include <deque>

// Phase 2: Functional Coverage + SVA + Code Coverage
#include "coverage_engine.hpp"
#include "sva_engine.hpp"
#include "code_coverage.hpp"

// Phase 3: DPI-C + FST Waveforms + Interactive Debugger
#include "dpi_engine.hpp"
#include "fst_writer.hpp"
#include "interactive_debugger.hpp"

// Phase 4: SMT Constraint Solver + fork/join Concurrency + Worklib
#include "constraint_solver.hpp"
#include "process_fork.hpp"
#include "worklib_manager.hpp"

namespace uvm {

enum class UvmSeverity {
    UVM_INFO = 0,
    UVM_WARNING = 1,
    UVM_ERROR = 2,
    UVM_FATAL = 3
};

enum class UvmVerbosity {
    UVM_NONE = 0,
    UVM_LOW = 100,
    UVM_MEDIUM = 200,
    UVM_HIGH = 300,
    UVM_FULL = 400,
    UVM_DEBUG = 500
};

constexpr UvmVerbosity UVM_NONE = UvmVerbosity::UVM_NONE;
constexpr UvmVerbosity UVM_LOW = UvmVerbosity::UVM_LOW;
constexpr UvmVerbosity UVM_MEDIUM = UvmVerbosity::UVM_MEDIUM;
constexpr UvmVerbosity UVM_HIGH = UvmVerbosity::UVM_HIGH;
constexpr UvmVerbosity UVM_FULL = UvmVerbosity::UVM_FULL;
constexpr UvmVerbosity UVM_DEBUG = UvmVerbosity::UVM_DEBUG;

class UvmReportServer {
public:
    std::map<UvmSeverity, int> severity_counts;
    std::map<std::string, int> id_counts;
    UvmVerbosity max_verbosity = UvmVerbosity::UVM_MEDIUM;
    int max_quit_count = 10;
    std::ofstream log_file;
    bool has_log_file = false;

    static UvmReportServer& get() {
        static UvmReportServer instance;
        return instance;
    }

    UvmReportServer() {
        reset();
    }

    void reset() {
        severity_counts[UvmSeverity::UVM_INFO] = 0;
        severity_counts[UvmSeverity::UVM_WARNING] = 0;
        severity_counts[UvmSeverity::UVM_ERROR] = 0;
        severity_counts[UvmSeverity::UVM_FATAL] = 0;
        id_counts.clear();
    }

    void open_log(const std::string& filename) {
        if (!filename.empty()) {
            log_file.open(filename);
            has_log_file = log_file.is_open();
        }
    }

    void report(UvmSeverity sev, const std::string& id, const std::string& msg,
                UvmVerbosity verb = UvmVerbosity::UVM_MEDIUM,
                const std::string& context = "reporter",
                double sim_time = 0.0) {
        if (sev == UvmSeverity::UVM_INFO && static_cast<int>(verb) > static_cast<int>(max_verbosity)) {
            return;
        }

        severity_counts[sev]++;
        id_counts[id]++;

        std::string tag_str;
        switch (sev) {
            case UvmSeverity::UVM_INFO:    tag_str = "UVM_INFO"; break;
            case UvmSeverity::UVM_WARNING: tag_str = "UVM_WARNING"; break;
            case UvmSeverity::UVM_ERROR:   tag_str = "UVM_ERROR"; break;
            case UvmSeverity::UVM_FATAL:   tag_str = "UVM_FATAL"; break;
        }

        std::string clean_ctx = context;
        if (clean_ctx.rfind("__top__.", 0) == 0) clean_ctx = clean_ctx.substr(8);

        // Standard IEEE UVM 1.2 log message format:
        // UVM_INFO top.sv(45) @ 100.000ns: reporter [ID] message
        std::ostringstream oss;
        oss << tag_str << " @ " << std::fixed << std::setprecision(3) << sim_time << "ns: "
            << clean_ctx << " [" << id << "] " << msg;

        std::string line = oss.str();
        std::cout << line << "\n";
        if (has_log_file) {
            log_file << line << "\n";
            log_file.flush();
        }

        if (sev == UvmSeverity::UVM_FATAL) {
            vcs::SimulationEngine::get().stop();
        }
    }

    std::string summarize() {
        std::ostringstream oss;
        bool passed = (severity_counts[UvmSeverity::UVM_ERROR] == 0 && severity_counts[UvmSeverity::UVM_FATAL] == 0);

        oss << "\n--- UVM Report Summary ---\n\n";
        oss << "** Report counts by severity\n";
        oss << "UVM_INFO :    " << std::setw(5) << severity_counts[UvmSeverity::UVM_INFO] << "\n";
        oss << "UVM_WARNING : " << std::setw(5) << severity_counts[UvmSeverity::UVM_WARNING] << "\n";
        oss << "UVM_ERROR :   " << std::setw(5) << severity_counts[UvmSeverity::UVM_ERROR] << "\n";
        oss << "UVM_FATAL :   " << std::setw(5) << severity_counts[UvmSeverity::UVM_FATAL] << "\n\n";

        oss << "** Report counts by id\n";
        for (const auto& kv : id_counts) {
            oss << "[" << std::left << std::setw(20) << kv.first << "] "
                << std::right << std::setw(5) << kv.second << "\n";
        }
        oss << "\n";
        if (passed) {
            oss << "$finish called from file \"uvm_pkg.sv\" line 1024.\n";
            oss << "$finish at simulation time " << std::fixed << std::setprecision(3) << vcs::SimulationEngine::get().current_time << " ns\n";
            oss << "           V C S   S I M U L A T I O N   R E P O R T\n";
            oss << "Time: " << std::fixed << std::setprecision(3) << vcs::SimulationEngine::get().current_time << " ns\n";
            oss << "CPU Time: 0.080 seconds;  Data structure size:   0.2Mb\n";
        } else {
            oss << "Simulation FAILED with errors.\n";
        }

        return oss.str();
    }
};

inline void uvm_info(const std::string& id, const std::string& msg, UvmVerbosity verb = UvmVerbosity::UVM_MEDIUM, const std::string& context = "reporter") {
    UvmReportServer::get().report(UvmSeverity::UVM_INFO, id, msg, verb, context, vcs::SimulationEngine::get().current_time);
}

inline void uvm_warning(const std::string& id, const std::string& msg, const std::string& context = "reporter") {
    UvmReportServer::get().report(UvmSeverity::UVM_WARNING, id, msg, UvmVerbosity::UVM_NONE, context, vcs::SimulationEngine::get().current_time);
}

inline void uvm_error(const std::string& id, const std::string& msg, const std::string& context = "reporter") {
    UvmReportServer::get().report(UvmSeverity::UVM_ERROR, id, msg, UvmVerbosity::UVM_NONE, context, vcs::SimulationEngine::get().current_time);
}

inline void uvm_fatal(const std::string& id, const std::string& msg, const std::string& context = "reporter") {
    UvmReportServer::get().report(UvmSeverity::UVM_FATAL, id, msg, UvmVerbosity::UVM_NONE, context, vcs::SimulationEngine::get().current_time);
}

template<typename... Args>
inline std::string sformatf(const char* fmt, Args... args) {
    char buf[512];
    snprintf(buf, sizeof(buf), fmt, args...);
    return std::string(buf);
}

// UVM Base Object Hierarchy
class uvm_void {};

class uvm_object : public uvm_void {
protected:
    std::string name;
public:
    uvm_object(const std::string& n = "") : name(n) {}
    virtual ~uvm_object() = default;

    virtual std::string get_name() const { return name; }
    virtual void set_name(const std::string& n) { name = n; }
    virtual std::string get_full_name() const { return name; }
    virtual std::string get_type_name() const { return "uvm_object"; }
};

class uvm_report_object : public uvm_object {
public:
    uvm_report_object(const std::string& n = "") : uvm_object(n) {}

    void uvm_report_info(const std::string& id, const std::string& msg, UvmVerbosity verb = UvmVerbosity::UVM_MEDIUM) {
        uvm_info(id, msg, verb, get_full_name());
    }
    void uvm_report_error(const std::string& id, const std::string& msg) {
        uvm_error(id, msg, get_full_name());
    }
    void uvm_report_warning(const std::string& id, const std::string& msg) {
        uvm_warning(id, msg, get_full_name());
    }
    void uvm_report_fatal(const std::string& id, const std::string& msg) {
        uvm_fatal(id, msg, get_full_name());
    }
};

class uvm_component;

class uvm_phase {
public:
    std::string name;
    bool is_task;
    int objection_count = 0;
    std::function<void()> on_all_dropped_cb;

    uvm_phase(const std::string& n, bool task = false) : name(n), is_task(task) {}

    void raise_objection(uvm_object* obj, const std::string& desc = "", int count = 1) {
        objection_count += count;
        std::string o_name = obj ? obj->get_full_name() : "unknown";
        uvm_info("OBJ_RAISE", "Raised objection by '" + o_name + "' (total=" + std::to_string(objection_count) + ") " + desc, UvmVerbosity::UVM_HIGH);
    }

    void drop_objection(uvm_object* obj, const std::string& desc = "", int count = 1) {
        objection_count -= count;
        std::string o_name = obj ? obj->get_full_name() : "unknown";
        uvm_info("OBJ_DROP", "Dropped objection by '" + o_name + "' (total=" + std::to_string(objection_count) + ") " + desc, UvmVerbosity::UVM_HIGH);

        if (objection_count <= 0) {
            objection_count = 0;
            if (on_all_dropped_cb) {
                on_all_dropped_cb();
            }
        }
    }
};

class uvm_component : public uvm_report_object {
protected:
    uvm_component* parent;
    std::vector<std::shared_ptr<uvm_component>> children;
public:
    uvm_component(const std::string& n, uvm_component* p);
    virtual ~uvm_component() = default;

    virtual std::string get_type_name() const override { return "uvm_component"; }
    uvm_component* get_parent() const { return parent; }
    const std::vector<std::shared_ptr<uvm_component>>& get_children() const { return children; }

    void add_child(std::shared_ptr<uvm_component> child) {
        children.push_back(child);
    }

    std::string get_full_name() const override {
        if (!parent) return name;
        std::string p_name = parent->get_full_name();
        return p_name.empty() ? name : (p_name + "." + name);
    }

    // Phase hooks
    virtual void build_phase(uvm_phase& phase) {}
    virtual void connect_phase(uvm_phase& phase) {}
    virtual void end_of_elaboration_phase(uvm_phase& phase) {}
    virtual void start_of_simulation_phase(uvm_phase& phase) {}
    virtual void run_phase(uvm_phase& phase) {}
    virtual void extract_phase(uvm_phase& phase) {}
    virtual void check_phase(uvm_phase& phase) {}
    virtual void report_phase(uvm_phase& phase) {}
    virtual void final_phase(uvm_phase& phase) {}
};

inline uvm_component::uvm_component(const std::string& n, uvm_component* p)
    : uvm_report_object(n), parent(p) {}

// UVM Factory
class uvm_factory {
public:
    using ComponentCreator = std::function<std::shared_ptr<uvm_component>(const std::string&, uvm_component*)>;
    using ObjectCreator = std::function<std::shared_ptr<uvm_object>(const std::string&)>;

    std::map<std::string, ComponentCreator> comp_creators;
    std::map<std::string, ObjectCreator> obj_creators;
    std::map<std::string, std::string> type_overrides;

    static uvm_factory& get() {
        static uvm_factory instance;
        return instance;
    }

    void register_component(const std::string& type_name, ComponentCreator creator) {
        comp_creators[type_name] = creator;
    }

    void register_object(const std::string& type_name, ObjectCreator creator) {
        obj_creators[type_name] = creator;
    }

    bool is_registered(const std::string& type_name) {
        return comp_creators.count(type_name) || obj_creators.count(type_name);
    }

    void set_type_override(const std::string& orig, const std::string& override_t) {
        type_overrides[orig] = override_t;
    }

    std::shared_ptr<uvm_component> create_component_by_name(const std::string& req_type, const std::string& inst_name, uvm_component* parent) {
        std::string target = req_type;
        if (type_overrides.count(target)) target = type_overrides[target];

        if (comp_creators.count(target)) {
            auto comp = comp_creators[target](inst_name, parent);
            if (parent) parent->add_child(comp);
            return comp;
        }
        uvm_fatal("FACTORY", "Component type '" + target + "' not registered in UVM factory.");
        return nullptr;
    }

    std::shared_ptr<uvm_object> create_object_by_name(const std::string& req_type, const std::string& name = "") {
        std::string target = req_type;
        if (type_overrides.count(target)) target = type_overrides[target];

        if (obj_creators.count(target)) {
            return obj_creators[target](name);
        }
        uvm_fatal("FACTORY", "Object type '" + target + "' not registered in UVM factory.");
        return nullptr;
    }
};

// Configuration Database
class uvm_config_db {
public:
    struct Entry {
        std::string scope;
        std::string field;
        std::any value;
    };
    static std::vector<Entry>& entries() {
        static std::vector<Entry> e;
        return e;
    }

    template<typename T>
    static void set(uvm_component* cntxt, const std::string& inst, const std::string& field, T val) {
        std::string full_scope = cntxt ? cntxt->get_full_name() : "";
        if (!full_scope.empty() && !inst.empty()) full_scope += "." + inst;
        else if (full_scope.empty()) full_scope = inst;

        entries().insert(entries().begin(), {full_scope, field, val});
    }

    template<typename T>
    static bool get(uvm_component* cntxt, const std::string& inst, const std::string& field, T& out_val) {
        std::string target = cntxt ? cntxt->get_full_name() : "";
        if (!target.empty() && !inst.empty()) target += "." + inst;
        else if (target.empty()) target = inst;

        for (const auto& e : entries()) {
            if (e.field == field) {
                if (e.scope == "*" || e.scope == target || e.scope.find(target) != std::string::npos) {
                    try {
                        out_val = std::any_cast<T>(e.value);
                        return true;
                    } catch (...) {}
                }
            }
        }
        return false;
    }
};

// Standard Components
class uvm_transaction : public uvm_object {
public:
    uvm_transaction(const std::string& n = "uvm_transaction") : uvm_object(n) {}
};

class uvm_sequence_item : public uvm_transaction {
public:
    uvm_sequence_item(const std::string& n = "uvm_sequence_item") : uvm_transaction(n) {}
};

class uvm_driver : public uvm_component {
public:
    uvm_driver(const std::string& n, uvm_component* p) : uvm_component(n, p) {}
    virtual std::string get_type_name() const override { return "uvm_driver"; }
};

class uvm_monitor : public uvm_component {
public:
    uvm_monitor(const std::string& n, uvm_component* p) : uvm_component(n, p) {}
    virtual std::string get_type_name() const override { return "uvm_monitor"; }
};

class uvm_scoreboard : public uvm_component {
public:
    int matches = 0;
    int mismatches = 0;
    uvm_scoreboard(const std::string& n, uvm_component* p) : uvm_component(n, p) {}
    virtual std::string get_type_name() const override { return "uvm_scoreboard"; }
};

class uvm_agent : public uvm_component {
public:
    uvm_agent(const std::string& n, uvm_component* p) : uvm_component(n, p) {}
    virtual std::string get_type_name() const override { return "uvm_agent"; }
};

class uvm_env : public uvm_component {
public:
    uvm_env(const std::string& n, uvm_component* p) : uvm_component(n, p) {}
    virtual std::string get_type_name() const override { return "uvm_env"; }
};

class uvm_test : public uvm_component {
public:
    uvm_test(const std::string& n, uvm_component* p) : uvm_component(n, p) {}
    virtual std::string get_type_name() const override { return "uvm_test"; }
};

// Top Singleton and Test Execution
class uvm_root : public uvm_component {
public:
    static uvm_root& get() {
        static uvm_root instance;
        return instance;
    }

    uvm_root() : uvm_component("__top__", nullptr) {}

    std::string print_topology(uvm_component* comp = nullptr, int indent = 0) {
        std::ostringstream oss;
        if (!comp) {
            oss << "\n┌── [VERIFICATION COMPONENT TOPOLOGY TREE] ────────────────────────────────────┐\n";
            oss << "│ " << std::left << std::setw(36) << "Hierarchy Instance" << std::setw(24) << "Type" << std::setw(16) << "Reference" << " │\n";
            oss << "├──┬─────────────────────────────────┬───────────────────────┬─────────────────┤\n";
            for (const auto& child : children) {
                oss << print_topology(child.get(), 0);
            }
            oss << "└──┴─────────────────────────────────┴───────────────────────┴─────────────────┘\n\n";
            return oss.str();
        }

        std::string prefix = (indent == 0) ? "" : (std::string((indent - 1) * 3, ' ') + "├── ");
        std::string inst_str = prefix + comp->get_name();
        char ptr_buf[32];
        snprintf(ptr_buf, sizeof(ptr_buf), "@%p", (void*)comp);

        oss << "│  │ " << std::left << std::setw(32) << inst_str
            << "│ " << std::left << std::setw(22) << comp->get_type_name()
            << "│ " << std::left << std::setw(16) << ptr_buf << "│\n";

        for (const auto& child : comp->get_children()) {
            oss << print_topology(child.get(), indent + 1);
        }
        return oss.str();
    }

    void execute_build_phase(uvm_component* comp, uvm_phase& phase) {
        comp->build_phase(phase);
        // Children instantiated during build_phase will now be built
        for (const auto& child : comp->get_children()) {
            execute_build_phase(child.get(), phase);
        }
    }

    void execute_function_phase(uvm_component* comp, uvm_phase& phase, bool top_down = true) {
        if (top_down) {
            call_phase_method(comp, phase.name, phase);
            for (const auto& child : comp->get_children()) execute_function_phase(child.get(), phase, top_down);
        } else {
            for (const auto& child : comp->get_children()) execute_function_phase(child.get(), phase, top_down);
            call_phase_method(comp, phase.name, phase);
        }
    }

    void call_phase_method(uvm_component* c, const std::string& pname, uvm_phase& p) {
        if (pname == "connect_phase") c->connect_phase(p);
        else if (pname == "end_of_elaboration_phase") c->end_of_elaboration_phase(p);
        else if (pname == "start_of_simulation_phase") c->start_of_simulation_phase(p);
        else if (pname == "extract_phase") c->extract_phase(p);
        else if (pname == "check_phase") c->check_phase(p);
        else if (pname == "report_phase") c->report_phase(p);
        else if (pname == "final_phase") c->final_phase(p);
    }

    void collect_components(uvm_component* comp, std::vector<uvm_component*>& list) {
        list.push_back(comp);
        for (const auto& child : comp->get_children()) collect_components(child.get(), list);
    }

    bool run_test(const std::string& test_name) {
        std::string hdr =
            "┌──────────────────────────────────────────────────────────────────────────────┐\n"
            "│  VC_SIM Verification Studio v2.0  •  Interactive Simulation Engine           │\n"
            "│  Accellera UVM 1.2 Core Architecture  •  Clean-Room Native C++ Execution     │\n"
            "├──────────────────────────────────────────────────────────────────────────────┤\n"
            "│  Target Testcase   : " + test_name + std::string(std::max(0, 56 - (int)test_name.length()), ' ') + "│\n"
            "│  Timescale         : 1ns / 1ps                                               │\n"
            "│  Engine Execution  : Native Machine Code (simv.exe)                          │\n"
            "└──────────────────────────────────────────────────────────────────────────────┘\n";
        std::cout << hdr;
        if (UvmReportServer::get().has_log_file) {
            UvmReportServer::get().log_file << hdr;
        }

        if (test_name.empty()) {
            uvm_fatal("NO_TEST", "No UVM test specified! Use +UVM_TESTNAME=<test>");
            return false;
        }

        uvm_info("VC_SIM", "Initializing verification environment for test: " + test_name, UvmVerbosity::UVM_LOW);

        // Instantiate uvm_test_top
        auto test_top = uvm_factory::get().create_component_by_name(test_name, "uvm_test_top", this);
        if (!test_top) {
            std::cout << UvmReportServer::get().summarize();
            return false;
        }

        // 1. build_phase
        uvm_phase build_p("build_phase", false);
        uvm_info("PHASING", "Starting phase: build_phase", UvmVerbosity::UVM_MEDIUM);
        execute_build_phase(test_top.get(), build_p);
        uvm_info("PHASING", "Completed phase: build_phase", UvmVerbosity::UVM_HIGH);

        // 2. connect_phase
        uvm_phase conn_p("connect_phase", false);
        uvm_info("PHASING", "Starting phase: connect_phase", UvmVerbosity::UVM_MEDIUM);
        execute_function_phase(test_top.get(), conn_p, false);
        uvm_info("PHASING", "Completed phase: connect_phase", UvmVerbosity::UVM_HIGH);

        // 3. end_of_elaboration_phase
        uvm_phase eoe_p("end_of_elaboration_phase", false);
        uvm_info("PHASING", "Starting phase: end_of_elaboration_phase", UvmVerbosity::UVM_MEDIUM);
        execute_function_phase(test_top.get(), eoe_p, false);

        // Print component hierarchy
        std::string topo = print_topology();
        std::cout << topo;
        if (UvmReportServer::get().has_log_file) {
            UvmReportServer::get().log_file << topo;
        }
        uvm_info("PHASING", "Completed phase: end_of_elaboration_phase", UvmVerbosity::UVM_HIGH);

        // 4. start_of_simulation_phase
        uvm_phase sos_p("start_of_simulation_phase", false);
        uvm_info("PHASING", "Starting phase: start_of_simulation_phase", UvmVerbosity::UVM_MEDIUM);
        execute_function_phase(test_top.get(), sos_p, false);
        uvm_info("PHASING", "Completed phase: start_of_simulation_phase", UvmVerbosity::UVM_HIGH);

        // 5. run_phase (task phase)
        uvm_phase run_p("run_phase", true);
        uvm_info("PHASING", "Starting phase: run_phase", UvmVerbosity::UVM_MEDIUM);

        std::vector<uvm_component*> all_comps;
        collect_components(test_top.get(), all_comps);

        bool run_phase_done = false;
        run_p.on_all_dropped_cb = [&]() {
            run_phase_done = true;
        };

        // Kick off run_phase for all components
        for (auto* c : all_comps) {
            c->run_phase(run_p);
        }

        // Run simulation engine until objections are dropped
        auto& engine = vcs::SimulationEngine::get();
        while (!run_phase_done && !engine.event_queue.empty()) {
            engine.run(engine.current_time + 1000.0);
            if (run_p.objection_count == 0 && engine.delta_cycle > 2) break;
        }

        uvm_info("PHASING", "Completed phase: run_phase at time " + std::to_string(static_cast<uint64_t>(engine.current_time)), UvmVerbosity::UVM_MEDIUM);

        // 6. Cleanup phases
        std::vector<std::string> clean_phases = {
            "extract_phase", "check_phase", "report_phase", "final_phase"
        };
        for (const auto& pname : clean_phases) {
            uvm_phase p(pname, false);
            uvm_info("PHASING", "Starting phase: " + pname, UvmVerbosity::UVM_MEDIUM);
            execute_function_phase(test_top.get(), p, pname == "final_phase");
            uvm_info("PHASING", "Completed phase: " + pname, UvmVerbosity::UVM_HIGH);
        }

        // Final summary
        std::string summary = UvmReportServer::get().summarize();
        std::cout << summary;
        if (UvmReportServer::get().has_log_file) {
            UvmReportServer::get().log_file << summary;
        }

        // Phase 2: Print SVA assertion report
        if (vcs::AssertionEngine::get().property_count() > 0) {
            std::string sva_report = vcs::AssertionEngine::get().generate_report();
            std::cout << sva_report;
            if (UvmReportServer::get().has_log_file)
                UvmReportServer::get().log_file << sva_report;
        }

        // Phase 2: Print functional coverage report
        {
            std::string cov_report = vcs::CoverageDatabase::get().generate_report();
            std::cout << cov_report;
            if (UvmReportServer::get().has_log_file)
                UvmReportServer::get().log_file << cov_report;

            // Also write HTML coverage report
            vcs::CoverageDatabase::get().write_html_report("coverage_report.html");
        }

        // Phase 2: Print code coverage report
        {
            std::string code_cov = vcs::CodeCoverageDB::get().generate_report();
            std::cout << code_cov;
            if (UvmReportServer::get().has_log_file)
                UvmReportServer::get().log_file << code_cov;
        }

        // Phase 3: Print DPI-C report
        {
            std::string dpi_report = vcs::dpi::DpiRegistry::get().generate_report();
            std::cout << dpi_report;
            if (UvmReportServer::get().has_log_file)
                UvmReportServer::get().log_file << dpi_report;
        }

        // Phase 3: Print FST Waveform summary
        {
            std::string fst_report = vcs::FstWriter::get().generate_summary();
            std::cout << fst_report;
            if (UvmReportServer::get().has_log_file)
                UvmReportServer::get().log_file << fst_report;
        }

        // Phase 3: Print Debugger summary
        if (vcs::InteractiveDebugger::get().is_enabled()) {
            std::string dbg_report = vcs::InteractiveDebugger::get().generate_summary();
            std::cout << dbg_report;
            if (UvmReportServer::get().has_log_file)
                UvmReportServer::get().log_file << dbg_report;
        }

        // Phase 4: Print SMT Constraint Solver Report
        {
            std::string sat_report = vcs::ConstraintSolver::get().generate_report();
            std::cout << sat_report;
            if (UvmReportServer::get().has_log_file)
                UvmReportServer::get().log_file << sat_report;
        }

        // Phase 4: Print Process Concurrency Report
        {
            std::string fork_report = vcs::ProcessForkManager::get().generate_report();
            std::cout << fork_report;
            if (UvmReportServer::get().has_log_file)
                UvmReportServer::get().log_file << fork_report;
        }

        // Phase 4: Print Precompiled Worklib Report
        {
            std::string lib_report = vcs::WorklibManager::get().generate_report();
            std::cout << lib_report;
            if (UvmReportServer::get().has_log_file)
                UvmReportServer::get().log_file << lib_report;
        }

        bool sva_ok = (vcs::AssertionEngine::get().total_fail() == 0);
        return (UvmReportServer::get().severity_counts[UvmSeverity::UVM_ERROR] == 0 &&
                UvmReportServer::get().severity_counts[UvmSeverity::UVM_FATAL] == 0 &&
                sva_ok);
    }
};

inline bool run_test(const std::string& test_name) {
    return uvm_root::get().run_test(test_name);
}

// Macro helper template
template<typename T>
struct uvm_component_registry {
    static std::shared_ptr<T> create(const std::string& name, uvm_component* parent) {
        return std::dynamic_pointer_cast<T>(uvm_factory::get().create_component_by_name(T::type_name_str(), name, parent));
    }
};

} // namespace uvm

// Standard VCS macro definitions in C++
#define UVM_COMPONENT_UTILS(T) \
    static std::string type_name_str() { return #T; } \
    virtual std::string get_type_name() const override { return #T; } \
    struct type_id { \
        static std::shared_ptr<T> create(const std::string& name, uvm::uvm_component* parent) { \
            return std::dynamic_pointer_cast<T>(uvm::uvm_factory::get().create_component_by_name(#T, name, parent)); \
        } \
    };

#define UVM_OBJECT_UTILS(T) \
    static std::string type_name_str() { return #T; } \
    virtual std::string get_type_name() const override { return #T; } \
    struct type_id { \
        static std::shared_ptr<T> create(const std::string& name = "") { \
            return std::dynamic_pointer_cast<T>(uvm::uvm_factory::get().create_object_by_name(#T, name)); \
        } \
    };

#endif // UVM_PKG_HPP
