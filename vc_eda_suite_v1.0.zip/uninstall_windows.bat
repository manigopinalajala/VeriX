@echo off
setlocal EnableDelayedExpansion

echo ================================================================================
echo   VC_SIM ^& VC_WAVE EDA SUITE - UNINSTALLER
echo ================================================================================
echo.

set "INSTALL_DIR=%~dp0"
if "%INSTALL_DIR:~-1%"=="\" set "INSTALL_DIR=%INSTALL_DIR:~0,-1%"
set "BIN_DIR=%INSTALL_DIR%\bin"

echo [*] Removing bin directory from User PATH...
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
    "$binDir = [System.IO.Path]::GetFullPath('%BIN_DIR%'); " ^
    "$userPath = [Environment]::GetEnvironmentVariable('Path', 'User'); " ^
    "if ($userPath) { " ^
    "    $entries = $userPath -split ';' | Where-Object { $_ -and $_ -ne $binDir }; " ^
    "    $newPath = $entries -join ';'; " ^
    "    [Environment]::SetEnvironmentVariable('Path', $newPath, 'User'); " ^
    "    Write-Host '[SUCCESS] Removed from User PATH:' $binDir; " ^
    "}"

echo [*] Removing Desktop shortcut...
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
    "$desktop = [Environment]::GetFolderPath('Desktop'); " ^
    "$scPath = Join-Path $desktop 'VC_Wave.lnk'; " ^
    "if (Test-Path $scPath) { Remove-Item $scPath -Force; Write-Host '[SUCCESS] Removed shortcut from Desktop.'; }"

echo.
echo ================================================================================
echo   UNINSTALLATION COMPLETE.
echo ================================================================================
pause
