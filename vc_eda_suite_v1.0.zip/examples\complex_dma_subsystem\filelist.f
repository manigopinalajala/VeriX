// Filelist for Complex DMA & AXI4-Lite Subsystem
+incdir+./rtl
+incdir+./tb

// RTL Submodules
./rtl/sync_fifo.v
./rtl/round_robin_arbiter.v
./rtl/crc32_engine.v
./rtl/dual_port_sram.v
./rtl/interrupt_controller.v
./rtl/dma_engine.v
./rtl/axi_lite_slave.v
./rtl/dma_axi_subsystem_top.v

// Top-Level Testbench
./tb/tb_dma_axi_subsystem.v
