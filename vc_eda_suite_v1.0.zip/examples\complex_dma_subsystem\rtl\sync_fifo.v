// =============================================================================
// File: sync_fifo.v
// Module: sync_fifo
// Description: Synchronous FIFO with configurable width and depth, parameterized
//              watermark thresholds, and status flags.
// =============================================================================

`timescale 1ns / 1ps

module sync_fifo #(
    parameter DATA_WIDTH = 32,
    parameter ADDR_WIDTH = 4,    // Depth = 16
    parameter ALMOST_FULL_THRESH  = 14,
    parameter ALMOST_EMPTY_THRESH = 2
)(
    input  wire                  clk,
    input  wire                  resetn,
    
    // Write Interface
    input  wire                  wr_en,
    input  wire [DATA_WIDTH-1:0] wr_data,
    output wire                  full,
    output wire                  almost_full,
    output reg                   overflow_err,
    
    // Read Interface
    input  wire                  rd_en,
    output wire [DATA_WIDTH-1:0] rd_data,
    output wire                  empty,
    output wire                  almost_empty,
    output reg                   underflow_err,
    
    // Occupancy Status
    output wire [ADDR_WIDTH:0]   occupancy
);

    localparam DEPTH = 1 << ADDR_WIDTH;

    // Internal Memory Array
    reg [DATA_WIDTH-1:0] mem [0:DEPTH-1];

    // Pointers and Count
    reg [ADDR_WIDTH-1:0] wr_ptr;
    reg [ADDR_WIDTH-1:0] rd_ptr;
    reg [ADDR_WIDTH:0]   count;

    // Status Flags
    assign empty        = (count == 0);
    assign full         = (count == DEPTH);
    assign almost_empty = (count <= ALMOST_EMPTY_THRESH);
    assign almost_full  = (count >= ALMOST_FULL_THRESH);
    assign occupancy    = count;
    assign rd_data      = mem[rd_ptr];

    // Synchronous Read/Write and Pointer Management
    always @(posedge clk or negedge resetn) begin
        if (!resetn) begin
            wr_ptr        <= {ADDR_WIDTH{1'b0}};
            rd_ptr        <= {ADDR_WIDTH{1'b0}};
            count         <= {(ADDR_WIDTH+1){1'b0}};
            overflow_err  <= 1'b0;
            underflow_err <= 1'b0;
        end else begin
            overflow_err  <= 1'b0;
            underflow_err <= 1'b0;

            case ({wr_en && !full, rd_en && !empty})
                2'b10: begin // Write only
                    mem[wr_ptr] <= wr_data;
                    wr_ptr      <= wr_ptr + 1'b1;
                    count       <= count + 1'b1;
                end
                2'b01: begin // Read only
                    rd_ptr <= rd_ptr + 1'b1;
                    count  <= count - 1'b1;
                end
                2'b11: begin // Simultaneous Write and Read
                    mem[wr_ptr] <= wr_data;
                    wr_ptr      <= wr_ptr + 1'b1;
                    rd_ptr      <= rd_ptr + 1'b1;
                    // count remains unchanged
                end
                default: begin
                    if (wr_en && full)  overflow_err  <= 1'b1;
                    if (rd_en && empty) underflow_err <= 1'b1;
                end
            endcase
        end
    end

endmodule
