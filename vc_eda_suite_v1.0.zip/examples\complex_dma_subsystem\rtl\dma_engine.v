// =============================================================================
// File: dma_engine.v
// Module: dma_engine
// Description: Multi-Cycle Direct Memory Access (DMA) Master Engine.
//              Reads contiguous bursts from Dual-Port SRAM and streams them into
//              the Synchronous FIFO and CRC32 accelerator.
// =============================================================================

`timescale 1ns / 1ps

module dma_engine (
    input  wire        clk,
    input  wire        resetn,
    
    // Control Commands from AXI Slave Register Bank
    input  wire        start_cmd,
    input  wire        abort_cmd,
    input  wire [7:0]  src_addr_in,
    input  wire [7:0]  xfer_len_words, // Number of 32-bit words (1..255)
    
    // Status to AXI Slave Register Bank
    output reg         busy,
    output reg         done_pulse,
    output reg         error_flag,
    output reg  [7:0]  words_transferred,
    
    // Memory Read Master Port (connects to Dual-Port SRAM Port B)
    output reg         sram_en,
    output reg  [7:0]  sram_addr,
    input  wire [31:0] sram_rdata,
    
    // FIFO Stream Master Port
    output reg         fifo_wr_en,
    output reg  [31:0] fifo_wr_data,
    input  wire        fifo_full,
    
    // CRC Accelerator Stream Master Port
    output reg         crc_valid,
    output reg  [31:0] crc_data
);

    // FSM State Encoding
    localparam [2:0] ST_IDLE       = 3'b000;
    localparam [2:0] ST_READ_ADDR  = 3'b001;
    localparam [2:0] ST_READ_DATA  = 3'b010;
    localparam [2:0] ST_PUSH_FIFO  = 3'b011;
    localparam [2:0] ST_CHECK_DONE = 3'b100;
    localparam [2:0] ST_FINISH     = 3'b101;
    localparam [2:0] ST_ABORT      = 3'b110;

    reg [2:0] state;
    reg [7:0] current_addr;
    reg [7:0] remaining_words;
    reg [31:0] latched_data;

    always @(posedge clk or negedge resetn) begin
        if (!resetn) begin
            state             <= ST_IDLE;
            busy              <= 1'b0;
            done_pulse        <= 1'b0;
            error_flag        <= 1'b0;
            words_transferred <= 8'd0;
            current_addr      <= 8'd0;
            remaining_words   <= 8'd0;
            sram_en           <= 1'b0;
            sram_addr         <= 8'd0;
            fifo_wr_en        <= 1'b0;
            fifo_wr_data      <= 32'd0;
            crc_valid         <= 1'b0;
            crc_data          <= 32'd0;
            latched_data      <= 32'd0;
        end else begin
            done_pulse <= 1'b0; // Default pulse
            fifo_wr_en <= 1'b0;
            crc_valid  <= 1'b0;

            if (abort_cmd && busy) begin
                state      <= ST_ABORT;
                error_flag <= 1'b1;
            end else begin
                case (state)
                    ST_IDLE: begin
                        busy       <= 1'b0;
                        sram_en    <= 1'b0;
                        if (start_cmd && (xfer_len_words > 0)) begin
                            busy              <= 1'b1;
                            error_flag        <= 1'b0;
                            words_transferred <= 8'd0;
                            current_addr      <= src_addr_in;
                            remaining_words   <= xfer_len_words;
                            state             <= ST_READ_ADDR;
                        end
                    end

                    ST_READ_ADDR: begin
                        if (!fifo_full) begin
                            sram_en   <= 1'b1;
                            sram_addr <= current_addr;
                            state     <= ST_READ_DATA;
                        end
                    end

                    ST_READ_DATA: begin
                        sram_en      <= 1'b0;
                        latched_data <= sram_rdata;
                        state        <= ST_PUSH_FIFO;
                    end

                    ST_PUSH_FIFO: begin
                        if (!fifo_full) begin
                            // Push word into FIFO
                            fifo_wr_en   <= 1'b1;
                            fifo_wr_data <= latched_data;

                            // Stream word concurrently into CRC accelerator
                            crc_valid    <= 1'b1;
                            crc_data     <= latched_data;

                            words_transferred <= words_transferred + 1'b1;
                            current_addr      <= current_addr + 1'b1;
                            remaining_words   <= remaining_words - 1'b1;
                            state             <= ST_CHECK_DONE;
                        end
                    end

                    ST_CHECK_DONE: begin
                        if (remaining_words == 0) begin
                            state <= ST_FINISH;
                        end else begin
                            state <= ST_READ_ADDR;
                        end
                    end

                    ST_FINISH: begin
                        busy       <= 1'b0;
                        done_pulse <= 1'b1;
                        state      <= ST_IDLE;
                    end

                    ST_ABORT: begin
                        busy       <= 1'b0;
                        sram_en    <= 1'b0;
                        fifo_wr_en <= 1'b0;
                        state      <= ST_IDLE;
                    end

                    default: state <= ST_IDLE;
                endcase
            end
        end
    end

endmodule
