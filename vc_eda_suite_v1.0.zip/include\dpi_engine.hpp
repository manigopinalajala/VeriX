#ifndef DPI_ENGINE_HPP
#define DPI_ENGINE_HPP

// ============================================================
//  VC_SIM Phase 3 – SystemVerilog DPI-C Foreign Architecture
//  IEEE 1800 Direct Programming Interface (DPI-C) Implementation
//  Supports:
//   - IEEE 1800 DPI standard data types (svBit, svLogic, svScalar, svBitVecVal)
//   - Scope management (svScope, svSetScope, svGetScope, svGetName)
//   - Import "DPI-C" foreign function calls
//   - Export "DPI-C" task/function callbacks
//   - Dynamic foreign function registry & argument marshalling
// ============================================================

#include <string>
#include <vector>
#include <unordered_map>
#include <functional>
#include <any>
#include <memory>
#include <iostream>
#include <sstream>
#include <iomanip>
#include <cstdint>

// ──────────────────────────────────────────────
//  IEEE 1800 Standard DPI-C Types
// ──────────────────────────────────────────────
typedef uint8_t  svBit;
typedef uint8_t  svLogic;
typedef uint8_t  svScalar;
typedef uint32_t svBitVecVal;
typedef struct {
    uint32_t a;
    uint32_t b;
} svLogicVecVal;

typedef void* svScope;
typedef void* svOpenArrayHandle;

namespace vcs {
namespace dpi {

struct DpiScopeContext {
    std::string scope_name;
    std::string file_name;
    int line_number = 0;
};

// ──────────────────────────────────────────────
//  DPI Function Signature & Metadata
// ──────────────────────────────────────────────
enum class DpiDirection { INPUT, OUTPUT, INOUT };

struct DpiArg {
    std::string name;
    std::string type_name;
    DpiDirection dir;
};

class DpiFunction {
public:
    std::string name;
    std::string c_identifier;
    std::string return_type;
    bool is_context = false;
    bool is_pure = false;
    std::vector<DpiArg> args;
    uint64_t call_count = 0;

    std::function<std::any(const std::vector<std::any>&)> invoker;

    DpiFunction() = default;
    DpiFunction(const std::string& sv_name, const std::string& c_name, const std::string& ret, bool ctx = false)
        : name(sv_name), c_identifier(c_name), return_type(ret), is_context(ctx) {}
};

// ──────────────────────────────────────────────
//  Global DPI Registry Singleton
// ──────────────────────────────────────────────
class DpiRegistry {
private:
    std::unordered_map<std::string, DpiFunction> imported_functions_;
    std::unordered_map<std::string, DpiFunction> exported_functions_;
    std::unordered_map<std::string, std::shared_ptr<DpiScopeContext>> scopes_;
    DpiScopeContext* current_scope_ = nullptr;

    DpiRegistry() = default;

public:
    static DpiRegistry& get() {
        static DpiRegistry inst;
        return inst;
    }

    void register_import(const DpiFunction& fn) {
        imported_functions_[fn.name] = fn;
    }

    void register_export(const DpiFunction& fn) {
        exported_functions_[fn.name] = fn;
    }

    DpiFunction* get_import(const std::string& name) {
        auto it = imported_functions_.find(name);
        return (it != imported_functions_.end()) ? &it->second : nullptr;
    }

    DpiFunction* get_export(const std::string& name) {
        auto it = exported_functions_.find(name);
        return (it != exported_functions_.end()) ? &it->second : nullptr;
    }

    void set_scope(const std::string& scope_name, const std::string& file = "", int line = 0) {
        if (scopes_.find(scope_name) == scopes_.end()) {
            auto s = std::make_shared<DpiScopeContext>();
            s->scope_name = scope_name;
            s->file_name = file;
            s->line_number = line;
            scopes_[scope_name] = s;
        }
        current_scope_ = scopes_[scope_name].get();
    }

    DpiScopeContext* get_current_scope() const {
        return current_scope_;
    }

    // Call an imported C foreign function
    std::any call_import(const std::string& name, const std::vector<std::any>& args) {
        auto* fn = get_import(name);
        if (!fn) {
            std::cerr << "\033[1;31m[DPI-C ERROR] Unresolved foreign import function: " << name << "\033[0m\n";
            return {};
        }
        fn->call_count++;
        if (fn->invoker) {
            return fn->invoker(args);
        }
        return {};
    }

    std::string generate_report() const {
        std::ostringstream oss;
        oss << "\n";
        oss << "╔══════════════════════════════════════════════════════════════════════════════╗\n";
        oss << "║              VC_SIM DPI-C FOREIGN INTERFACE REPORT (Phase 3)                 ║\n";
        oss << "╠══════════════════════════════════════════════════════════════════════════════╣\n";
        oss << "║  Registered Foreign Imports  : " << std::setw(5) << imported_functions_.size()
            << "                                             ║\n";
        oss << "║  Registered Foreign Exports  : " << std::setw(5) << exported_functions_.size()
            << "                                             ║\n";
        oss << "╠══════════════════════════════════════════════════════════════════════════════╣\n";
        oss << "║  " << std::left << std::setw(26) << "Function (SV)"
            << " │ " << std::setw(24) << "C Symbol Binding"
            << " │ " << std::setw(8) << "Calls"
            << " │ Status   ║\n";
        oss << "╠══════════════════════════════════════════════════════════════════════════════╣\n";

        for (const auto& kv : imported_functions_) {
            const auto& fn = kv.second;
            oss << "║  " << std::left << std::setw(26) << fn.name
                << " │ " << std::setw(24) << fn.c_identifier
                << " │ " << std::right << std::setw(8) << fn.call_count
                << " │ " << (fn.call_count > 0 ? "✓ ACTIVE " : "• BOUND  ") << " ║\n";
        }
        oss << "╚══════════════════════════════════════════════════════════════════════════════╝\n";
        return oss.str();
    }
};

} // namespace dpi
} // namespace vcs

// ──────────────────────────────────────────────
//  IEEE 1800 Standard C API Definitions
// ──────────────────────────────────────────────
extern "C" {

inline svScope svGetScope(void) {
    return static_cast<svScope>(vcs::dpi::DpiRegistry::get().get_current_scope());
}

inline svScope svSetScope(const svScope scope) {
    auto* prev = vcs::dpi::DpiRegistry::get().get_current_scope();
    if (scope) {
        auto* ctx = static_cast<vcs::dpi::DpiScopeContext*>(scope);
        vcs::dpi::DpiRegistry::get().set_scope(ctx->scope_name, ctx->file_name, ctx->line_number);
    }
    return static_cast<svScope>(prev);
}

inline const char* svGetNameFromScope(const svScope scope) {
    if (!scope) return "";
    auto* ctx = static_cast<vcs::dpi::DpiScopeContext*>(scope);
    return ctx->scope_name.c_str();
}

inline const char* svGetFileName(void) {
    auto* ctx = vcs::dpi::DpiRegistry::get().get_current_scope();
    return ctx ? ctx->file_name.c_str() : "";
}

inline int svGetLineNumber(void) {
    auto* ctx = vcs::dpi::DpiRegistry::get().get_current_scope();
    return ctx ? ctx->line_number : 0;
}

} // extern "C"

#endif // DPI_ENGINE_HPP
