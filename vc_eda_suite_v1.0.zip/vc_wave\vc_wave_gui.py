#!/usr/bin/env python3
# ==============================================================================
# File: verdi_gui.py
# Description: Native Standalone Desktop EDA GUI Debugger (Verdi Advanced)
#              Runs directly on the desktop as a native application window.
#
# Workflows:
#   1. Starts CLEAN (no pre-loaded designs).
#   2. User opens a Waveform file (.vcd / .fst) via "📂 Open Waveform" or CLI.
#   3. Automatically locates, associates, and loads the respective RTL files
#      (via filelist.f or automatic directory scanning).
#   4. Reconstructs design hierarchy, ports, driver backtracing, load fanout,
#      and live in-line RTL signal value annotations.
# ==============================================================================

import sys
import os
import re
import json
import tkinter as tk
from tkinter import ttk, filedialog, messagebox

WELCOME_RTL = """// =============================================================================
//  VC_WAVE ADVANCED STANDALONE EDA DEBUGGER v2.5
// =============================================================================
//
//  Status: No design currently loaded.
//
//  HOW TO START DEBUGGING:
//  1. Click the "📂 Open Waveform" button on the toolbar (or File -> Open Waveform).
//  2. Select any simulation wave file (.vcd).
//  3. VC_Wave will AUTOMATICALLY discover, associate, and load all respective RTL files
//     from the project directory (via filelist.f or directory scan).
//
//  KEY CAPABILITIES:
//  • Split-screen nTrace (RTL Code) + nWave (Digital Waveforms)
//  • 🎯 Backtrace Driver (Ctrl+D) & ⏩ Trace Load / Fanout (Ctrl+L)
//  • ⚡ Cone of Influence / Drivers List
//  • ⬆️ Up Scope & ⬇️ Down Scope Hierarchy Navigation
//  • 🟢 Live In-Line Signal Value Annotation in RTL code synchronized to waveform cursor
//  • 📏 Dual Cursors (C1 & C2) with Delta Time (Δ) & Frequency calculation
//
// ============================================================================="""

class VcWaveNativeStudio(tk.Tk):
    def __init__(self, initial_vcd=None):
        super().__init__()
        self.title("VC_Wave Advanced EDA Debugger - [Standalone Native]")
        self.geometry("1400x900")
        self.minsize(1050, 680)
        self.configure(bg="#ece9d8")

        # Session State (starts empty)
        self.active_vcd_path = None
        self.active_project_name = "None"
        self.max_time = 100.0
        self.signals = []
        self.modules = {}
        self.current_scope = None
        self.selected_signal = None
        self.cursor_c1 = 0.0
        self.cursor_c2 = 20.0
        self.time_per_pixel = 1.0
        self.show_annotation = True
        self.radix = "HEX"
        self.dark_mode = False

        self._setup_styles()
        self._build_menu()
        self._build_toolbar()
        self._build_main_split()
        self._build_status_bar()

        # Keyboard shortcuts
        self.bind("<Control-d>", lambda e: self.action_backtrace())
        self.bind("<Control-D>", lambda e: self.action_backtrace())
        self.bind("<Control-l>", lambda e: self.action_trace_load())
        self.bind("<Control-L>", lambda e: self.action_trace_load())
        self.bind("<f>", lambda e: self.zoom_fit())
        self.bind("<F>", lambda e: self.zoom_fit())

        # Start with empty state
        self.reset_to_empty_state()

        # If user passed a VCD argument on command line, load it automatically
        if initial_vcd and os.path.exists(initial_vcd):
            self.after(200, lambda: self.load_waveform_and_auto_rtl(initial_vcd))

    def _setup_styles(self):
        self.style = ttk.Style(self)
        self.style.theme_use("clam")
        self.style.configure(".", font=("Segoe UI", 9))
        self.style.configure("Treeview", rowheight=20, font=("Consolas", 9))
        self.style.configure("TPanedwindow", background="#aca899")

    def _build_menu(self):
        menubar = tk.Menu(self, bg="#ece9d8", fg="#000")

        file_menu = tk.Menu(menubar, tearoff=0)
        file_menu.add_command(label="Open Waveform (VCD)...", command=self.open_vcd_dialog)
        file_menu.add_command(label="Open RTL Files...", command=self.open_rtl_dialog)
        file_menu.add_separator()
        file_menu.add_command(label="Close Session / Clear", command=self.reset_to_empty_state)
        file_menu.add_separator()
        file_menu.add_command(label="Exit", command=self.quit)
        menubar.add_cascade(label="File", menu=file_menu)

        trace_menu = tk.Menu(menubar, tearoff=0)
        trace_menu.add_command(label="Trace Driver (Ctrl+D)", command=self.action_backtrace)
        trace_menu.add_command(label="Trace Load (Ctrl+L)", command=self.action_trace_load)
        trace_menu.add_command(label="Drivers List", command=self.action_show_drivers)
        menubar.add_cascade(label="Trace", menu=trace_menu)

        hier_menu = tk.Menu(menubar, tearoff=0)
        hier_menu.add_command(label="Up Scope", command=self.nav_hierarchy_up)
        hier_menu.add_command(label="Down Scope", command=self.nav_hierarchy_down)
        menubar.add_cascade(label="Hierarchy", menu=hier_menu)

        view_menu = tk.Menu(menubar, tearoff=0)
        view_menu.add_command(label="Toggle Dark Theme", command=self.toggle_dark_theme)
        view_menu.add_command(label="Zoom Fit (F)", command=self.zoom_fit)
        menubar.add_cascade(label="View", menu=view_menu)

        self.config(menu=menubar)

    def _build_toolbar(self):
        tb = tk.Frame(self, bg="#ece9d8", height=34, relief=tk.RAISED, bd=1)
        tb.pack(side=tk.TOP, fill=tk.X, padx=2, pady=2)

        # Primary Load Button
        self.btn_open_vcd = tk.Button(tb, text="📂 Open Waveform", bg="#e8e0ff", font=("Segoe UI", 9, "bold"),
                                      fg="#330088", command=self.open_vcd_dialog, relief=tk.GROOVE)
        self.btn_open_vcd.pack(side=tk.LEFT, padx=3)

        tk.Frame(tb, width=1, height=22, bg="#aca899").pack(side=tk.LEFT, padx=5)

        # Hierarchy Buttons
        tk.Button(tb, text="⬆️ Up", bg="#f0ede0", command=self.nav_hierarchy_up, relief=tk.GROOVE).pack(side=tk.LEFT, padx=2)
        tk.Button(tb, text="⬇️ Down", bg="#f0ede0", command=self.nav_hierarchy_down, relief=tk.GROOVE).pack(side=tk.LEFT, padx=2)

        tk.Frame(tb, width=1, height=22, bg="#aca899").pack(side=tk.LEFT, padx=5)

        # Trace Buttons
        tk.Button(tb, text="🎯 Backtrace Driver", bg="#ffffbb", font=("Segoe UI", 9, "bold"),
                  command=self.action_backtrace, relief=tk.GROOVE).pack(side=tk.LEFT, padx=2)
        tk.Button(tb, text="⏩ Trace Load", bg="#f0ede0", command=self.action_trace_load, relief=tk.GROOVE).pack(side=tk.LEFT, padx=2)
        tk.Button(tb, text="⚡ Drivers List", bg="#f0ede0", command=self.action_show_drivers, relief=tk.GROOVE).pack(side=tk.LEFT, padx=2)

        tk.Frame(tb, width=1, height=22, bg="#aca899").pack(side=tk.LEFT, padx=5)

        # Value Annotation Toggle
        self.btn_anno = tk.Button(tb, text="🟢 RTL Values: ON", bg="#d4edda", font=("Segoe UI", 9, "bold"),
                                  command=self.toggle_annotation, relief=tk.GROOVE)
        self.btn_anno.pack(side=tk.LEFT, padx=2)

        # Radix
        tk.Label(tb, text="Radix:", bg="#ece9d8", font=("Segoe UI", 9, "bold")).pack(side=tk.LEFT, padx=(6, 2))
        self.radix_combo = ttk.Combobox(tb, values=["HEX", "BIN", "DEC"], state="readonly", width=6)
        self.radix_combo.current(0)
        self.radix_combo.bind("<<ComboboxSelected>>", lambda e: self.change_radix(self.radix_combo.get()))
        self.radix_combo.pack(side=tk.LEFT, padx=2)

        # Zoom Buttons
        tk.Button(tb, text="🔍 Fit", bg="#f0ede0", command=self.zoom_fit, relief=tk.GROOVE).pack(side=tk.LEFT, padx=2)
        tk.Button(tb, text="➕", bg="#f0ede0", command=self.zoom_in, relief=tk.GROOVE).pack(side=tk.LEFT, padx=1)
        tk.Button(tb, text="➖", bg="#f0ede0", command=self.zoom_out, relief=tk.GROOVE).pack(side=tk.LEFT, padx=1)

        # Timing Box
        self.time_lbl = tk.Label(tb, text="C1: 0.000 ns | C2: 0.000 ns | Δ: 0.000 ns",
                                 bg="#ffffff", fg="#000080", font=("Consolas", 9, "bold"), bd=1, relief=tk.SOLID, padx=6)
        self.time_lbl.pack(side=tk.RIGHT, padx=5)

    def _build_main_split(self):
        self.v_pane = tk.PanedWindow(self, orient=tk.VERTICAL, sashrelief=tk.RAISED, sashwidth=4, bg="#aca899")
        self.v_pane.pack(fill=tk.BOTH, expand=True, padx=2, pady=2)

        # ----------------------------- TOP: nTrace -----------------------------
        ntrace_frame = tk.Frame(self.v_pane, bg="#fff", bd=1, relief=tk.SOLID)
        self.v_pane.add(ntrace_frame, height=450)

        # Header
        hdr = tk.Frame(ntrace_frame, bg="#0a246a", height=24)
        hdr.pack(fill=tk.X)
        tk.Label(hdr, text="Verdi nTrace - [Source Code Debugger]", bg="#0a246a", fg="#fff", font=("Segoe UI", 9, "bold")).pack(side=tk.LEFT, padx=6)
        self.scope_lbl = tk.Label(hdr, text="No design loaded", bg="#0a246a", fg="#ffff99", font=("Consolas", 9))
        self.scope_lbl.pack(side=tk.RIGHT, padx=6)

        # Horizontal Split: Hierarchy on Left, RTL on Right
        h_trace = tk.PanedWindow(ntrace_frame, orient=tk.HORIZONTAL, sashrelief=tk.RAISED, sashwidth=4, bg="#aca899")
        h_trace.pack(fill=tk.BOTH, expand=True)

        # Hierarchy & Ports panel
        tree_frame = tk.Frame(h_trace, bg="#ece9d8", width=250)
        h_trace.add(tree_frame, width=250)

        tk.Label(tree_frame, text="Hierarchy Tree", bg="#ece9d8", font=("Segoe UI", 9, "bold")).pack(anchor=tk.W, padx=4, pady=2)
        self.hier_tree = ttk.Treeview(tree_frame, selectmode="browse", height=10)
        self.hier_tree.pack(fill=tk.BOTH, expand=True, padx=2)
        self.hier_tree.bind("<<TreeviewSelect>>", self._on_scope_select)

        tk.Label(tree_frame, text="Module Ports & Live Values", bg="#ece9d8", font=("Segoe UI", 9, "bold")).pack(anchor=tk.W, padx=4, pady=2)
        self.ports_tree = ttk.Treeview(tree_frame, columns=("Dir", "Value"), selectmode="browse", height=6)
        self.ports_tree.heading("#0", text="Port")
        self.ports_tree.heading("Dir", text="Dir")
        self.ports_tree.heading("Value", text="Value @ C1")
        self.ports_tree.column("#0", width=100)
        self.ports_tree.column("Dir", width=45)
        self.ports_tree.column("Value", width=95)
        self.ports_tree.pack(fill=tk.BOTH, expand=True, padx=2, pady=2)
        self.ports_tree.bind("<Double-1>", lambda e: self.action_backtrace())

        # Code View
        code_frame = tk.Frame(h_trace, bg="#fff")
        h_trace.add(code_frame)

        self.gutter = tk.Text(code_frame, width=5, bg="#ece9d8", fg="#555", font=("Consolas", 10), bd=0, state=tk.DISABLED)
        self.gutter.pack(side=tk.LEFT, fill=tk.Y)

        self.code_text = tk.Text(code_frame, bg="#ffffff", fg="#1a1a1a", font=("Consolas", 10), bd=0, wrap=tk.NONE)
        self.code_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        scrolly = tk.Scrollbar(code_frame, command=self._sync_scroll)
        scrolly.pack(side=tk.RIGHT, fill=tk.Y)
        self.code_text.config(yscrollcommand=lambda *args: (scrolly.set(*args), self.gutter.yview_moveto(args[0])))

        self.code_text.tag_configure("driver_hit", background="#ffff55", font=("Consolas", 10, "bold"))
        self.code_text.tag_configure("load_hit", background="#bfe3ff", font=("Consolas", 10, "bold"))
        self.code_text.tag_configure("comment", foreground="#008800", font=("Consolas", 10, "italic"))

        # ----------------------------- BOTTOM: nWave -----------------------------
        nwave_frame = tk.Frame(self.v_pane, bg="#000", bd=1, relief=tk.SOLID)
        self.v_pane.add(nwave_frame, height=350)

        w_hdr = tk.Frame(nwave_frame, bg="#2b5797", height=24)
        w_hdr.pack(fill=tk.X)
        tk.Label(w_hdr, text="Verdi nWave - [Digital Waveform Window]", bg="#2b5797", fg="#fff", font=("Segoe UI", 9, "bold")).pack(side=tk.LEFT, padx=6)
        self.wave_info_lbl = tk.Label(w_hdr, text="No waveform loaded", bg="#2b5797", fg="#ffff99", font=("Consolas", 9))
        self.wave_info_lbl.pack(side=tk.RIGHT, padx=6)

        h_wave = tk.PanedWindow(nwave_frame, orient=tk.HORIZONTAL, sashrelief=tk.RAISED, sashwidth=4, bg="#aca899")
        h_wave.pack(fill=tk.BOTH, expand=True)

        # Signals panel
        sig_frame = tk.Frame(h_wave, bg="#ece9d8", width=250)
        h_wave.add(sig_frame, width=250)

        self.sig_filter_entry = tk.Entry(sig_frame, font=("Segoe UI", 9))
        self.sig_filter_entry.pack(fill=tk.X, padx=3, pady=3)
        self.sig_filter_entry.insert(0, "Filter signals...")
        self.sig_filter_entry.bind("<KeyRelease>", lambda e: self.filter_signals(self.sig_filter_entry.get()))

        self.sig_tree = ttk.Treeview(sig_frame, columns=("Value"), selectmode="browse")
        self.sig_tree.heading("#0", text="Signal Name")
        self.sig_tree.heading("Value", text="Value @ C1")
        self.sig_tree.column("#0", width=150)
        self.sig_tree.column("Value", width=90)
        self.sig_tree.pack(fill=tk.BOTH, expand=True, padx=2, pady=2)
        self.sig_tree.bind("<<TreeviewSelect>>", self._on_signal_select)
        self.sig_tree.bind("<Double-1>", lambda e: self.action_backtrace())

        # Wave Canvas
        canvas_container = tk.Frame(h_wave, bg="#000")
        h_wave.add(canvas_container)

        self.ruler_canvas = tk.Canvas(canvas_container, bg="#1a1a1a", height=24, highlightthickness=0)
        self.ruler_canvas.pack(fill=tk.X)

        self.wave_canvas = tk.Canvas(canvas_container, bg="#050505", highlightthickness=0)
        self.wave_canvas.pack(fill=tk.BOTH, expand=True)
        self.wave_canvas.bind("<Button-1>", self._on_wave_click)
        self.wave_canvas.bind("<Shift-Button-1>", lambda e: self._on_wave_click(e, shift=True))
        self.wave_canvas.bind("<B1-Motion>", self._on_wave_drag)

    def _sync_scroll(self, *args):
        self.code_text.yview(*args)
        self.gutter.yview(*args)

    def _build_status_bar(self):
        sb = tk.Frame(self, bg="#ece9d8", height=22, relief=tk.SUNKEN, bd=1)
        sb.pack(side=tk.BOTTOM, fill=tk.X)
        self.stat_mode = tk.Label(sb, text="Mode: STANDBY", bg="#ece9d8", font=("Segoe UI", 9, "bold"), fg="#000080")
        self.stat_mode.pack(side=tk.LEFT, padx=8)

        self.stat_sig = tk.Label(sb, text="Signal: None", bg="#ece9d8", font=("Segoe UI", 9))
        self.stat_sig.pack(side=tk.LEFT, padx=12)

        self.stat_drv = tk.Label(sb, text="Driver: None", bg="#ece9d8", font=("Segoe UI", 9), fg="#990000")
        self.stat_drv.pack(side=tk.LEFT, padx=12)

        self.stat_val = tk.Label(sb, text="Value @ C1: -", bg="#ece9d8", font=("Segoe UI", 9, "bold"), fg="#005500")
        self.stat_val.pack(side=tk.LEFT, padx=12)

        self.stat_info = tk.Label(sb, text="Please open a waveform file to start debugging.", bg="#ece9d8", fg="#555")
        self.stat_info.pack(side=tk.RIGHT, padx=8)

    # --------------------------------------------------------------------------
    # Clean Initial State
    # --------------------------------------------------------------------------
    def reset_to_empty_state(self):
        self.active_vcd_path = None
        self.active_project_name = "None"
        self.max_time = 100.0
        self.signals = []
        self.modules = {}
        self.current_scope = None
        self.selected_signal = None
        self.cursor_c1 = 0.0
        self.cursor_c2 = 0.0

        self.scope_lbl.config(text="No design loaded")
        self.wave_info_lbl.config(text="No waveform loaded")
        self.time_lbl.config(text="C1: 0.000 ns | C2: 0.000 ns | Δ: 0.000 ns")
        self.stat_mode.config(text="Mode: STANDBY")
        self.stat_sig.config(text="Signal: None")
        self.stat_drv.config(text="Driver: None")
        self.stat_val.config(text="Value @ C1: -")
        self.stat_info.config(text="Ready. Please open a waveform file (.vcd).")

        self.hier_tree.delete(*self.hier_tree.get_children())
        self.ports_tree.delete(*self.ports_tree.get_children())
        self.sig_tree.delete(*self.sig_tree.get_children())

        # Render Welcome Screen in nTrace
        self.code_text.delete("1.0", tk.END)
        self.gutter.config(state=tk.NORMAL)
        self.gutter.delete("1.0", tk.END)
        for idx, line in enumerate(WELCOME_RTL.splitlines()):
            self.gutter.insert(tk.END, f"{idx+1:>4}\n")
            self.code_text.insert(tk.END, line + "\n")
        self.gutter.config(state=tk.DISABLED)

        # Empty Waveform Canvas with Callout
        self.ruler_canvas.delete("all")
        self.wave_canvas.delete("all")
        self.wave_canvas.create_text(
            350, 80,
            text='Click "📂 Open Waveform" to load a simulation trace.\n\nAll respective RTL files will be automatically loaded!',
            fill="#888888", font=("Segoe UI", 11, "bold"), justify=tk.CENTER
        )

    # --------------------------------------------------------------------------
    # Automatic Discovery & Loading: VCD -> Respective RTL Files
    # --------------------------------------------------------------------------
    def open_vcd_dialog(self):
        path = filedialog.askopenfilename(
            title="Open Simulation Waveform",
            filetypes=[("VCD Waveform Files", "*.vcd"), ("All Files", "*.*")]
        )
        if path:
            self.load_waveform_and_auto_rtl(path)

    def load_waveform_and_auto_rtl(self, vcd_path):
        vcd_path = os.path.abspath(vcd_path)
        if not os.path.isfile(vcd_path):
            messagebox.showerror("File Error", f"Waveform file not found:\n{vcd_path}")
            return

        self.stat_info.config(text=f"Parsing waveform: {os.path.basename(vcd_path)}...")
        self.update()

        # 1. Parse VCD Waveform signals
        parsed_signals, max_t = self._parse_vcd_file(vcd_path)
        if not parsed_signals:
            messagebox.showerror("Parse Error", f"No valid signals found in:\n{vcd_path}")
            return

        self.active_vcd_path = vcd_path
        self.active_project_name = os.path.basename(vcd_path)
        self.signals = parsed_signals
        self.max_time = max_t if max_t > 0 else 100.0
        self.cursor_c1 = 0.0
        self.cursor_c2 = min(self.max_time, 40.0)

        # 2. Try to extract embedded RTL snapshot from VCD (zero-friction path)
        embedded_files = self._extract_embedded_rtl_from_vcd(vcd_path)
        rtl_source = "embedded"

        if embedded_files:
            self._load_rtl_from_snapshot(embedded_files)
        else:
            # Fallback: discover RTL files on disk
            rtl_source = "disk"
            rtl_files = self._auto_discover_rtl_files(vcd_path)
            if rtl_files:
                self._load_rtl_files(rtl_files)
            else:
                rtl_source = "synthetic"
                self._create_fallback_modules_from_vcd(vcd_path)

        # 3. Setup views
        self.stat_mode.config(text="Mode: ACTIVE DEBUG")
        self.wave_info_lbl.config(text=f"Wave: {os.path.basename(vcd_path)} | Range: 0.000 ns - {self.max_time:.3f} ns")
        self.selected_signal = self.signals[0]["name"]

        self._populate_hierarchy()
        self._populate_signals()
        self._render_rtl()
        self.zoom_fit()
        self._update_timing_display()
        self._update_status()

        rtl_count = len(self.modules)
        source_label = {"embedded": "from VCD snapshot", "disk": "from project files", "synthetic": "synthesized from waveform"}[rtl_source]
        self.stat_info.config(text=f"Active Session: {os.path.basename(vcd_path)} ({len(self.signals)} signals, {rtl_count} RTL modules loaded {source_label})")

        messagebox.showinfo("Session Loaded Successfully",
                            f"✅ Waveform: {os.path.basename(vcd_path)}\n"
                            f"   • {len(self.signals)} active signals parsed\n"
                            f"   • Duration: {self.max_time} ns\n\n"
                            f"✅ Respective RTL: {rtl_count} modules auto-loaded ({source_label})!\n"
                            f"   • Top Module: {self.current_scope}\n\n"
                            f"Ready for interactive waveform debugging & back-tracing!")

    def _extract_embedded_rtl_from_vcd(self, vcd_path):
        """Extract embedded RTL source files from the VCD $comment [VERDI_RTL_SNAPSHOT] block."""
        try:
            with open(vcd_path, "r", encoding="utf-8", errors="ignore") as f:
                content = f.read(2_000_000)  # Read up to 2MB (snapshot is in the header)
            m = re.search(
                r'\[(?:VC_WAVE|VERDI)_RTL_SNAPSHOT_BEGIN\]\s*(.*?)\s*\[(?:VC_WAVE|VERDI)_RTL_SNAPSHOT_END\]',
                content, re.DOTALL
            )
            if not m:
                return None
            raw = m.group(1).strip()
            try:
                data = json.loads(raw)
            except json.JSONDecodeError:
                # Legacy double-escaped format from older vc_sim versions
                try:
                    unescaped = raw.encode().decode('unicode_escape')
                    data = json.loads(unescaped)
                except Exception:
                    return None
            return data.get("files", None)
        except Exception:
            return None

    def _load_rtl_from_snapshot(self, file_entries):
        """Load RTL modules directly from in-memory snapshot (no disk access needed)."""
        self.modules = {}
        for entry in file_entries:
            fpath = entry.get("path", "unknown.v")
            content_str = entry.get("content", "")
            fname = os.path.basename(fpath)
            lines = content_str.splitlines()

            mod_name = os.path.splitext(fname)[0]
            ports = []
            drivers = {}
            loads = {}

            for idx, line in enumerate(lines):
                l_num = idx + 1
                # Find module name
                m_match = re.search(r"\bmodule\s+([A-Za-z0-9_]+)", line)
                if m_match and not line.strip().startswith("//"):
                    mod_name = m_match.group(1)

                # Ports
                if "input" in line and not line.strip().startswith("//"):
                    parts = re.findall(r"\b[A-Za-z0-9_]+(?:\s*\[[^\]]+\])?\b", line)
                    if parts:
                        ports.append(("input", parts[-1].replace(";", "")))
                elif "output" in line and not line.strip().startswith("//"):
                    parts = re.findall(r"\b[A-Za-z0-9_]+(?:\s*\[[^\]]+\])?\b", line)
                    if parts:
                        ports.append(("output", parts[-1].replace(";", "")))

                # Drivers: assign <lhs> = <rhs>
                assign_match = re.search(r"\bassign\s+([A-Za-z0-9_]+(?:\s*\[[^\]]+\])?)\s*=", line)
                if assign_match:
                    lhs = assign_match.group(1).strip()
                    drivers[lhs] = {"line": l_num, "file": fname, "cause": line.strip()}

                # Drivers: <lhs> <= <rhs>
                nblk_match = re.search(r"([A-Za-z0-9_]+(?:\s*\[[^\]]+\])?)\s*<=", line)
                if nblk_match:
                    lhs = nblk_match.group(1).strip()
                    if lhs not in drivers:
                        drivers[lhs] = {"line": l_num, "file": fname, "cause": line.strip()}

            self.modules[mod_name] = {
                "file": fname,
                "full_path": fpath,
                "parent": None,
                "children": [],
                "ports": ports,
                "lines": lines,
                "drivers": drivers,
                "loads": loads
            }

        # Resolve top-level module
        if self.modules:
            top_cand = next((m for m in self.modules.keys() if "top" in m.lower()), list(self.modules.keys())[0])
            self.current_scope = top_cand

            # Set parent/children hierarchy relationships
            for m_name, m_info in self.modules.items():
                if m_name != self.current_scope:
                    m_info["parent"] = self.current_scope
                    self.modules[self.current_scope]["children"].append(m_name)

    def _parse_vcd_file(self, path):
        sig_map = {}
        current_t = 0.0
        max_t = 0.0

        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                if line.startswith("$var"):
                    parts = line.split()
                    if len(parts) >= 5:
                        w = int(parts[2]) if parts[2].isdigit() else 1
                        vid = parts[3]
                        name = parts[4]
                        # Clean name
                        clean_name = re.sub(r"\[.*\]", "", name)
                        sig_map[vid] = {"name": name, "clean": clean_name, "width": w, "changes": [(0.0, 0)]}
                elif line.startswith("#"):
                    try:
                        current_t = float(line[1:])
                        if current_t > max_t:
                            max_t = current_t
                    except:
                        pass
                elif line.startswith("b") or line.startswith("B"):
                    parts = line.split()
                    if len(parts) >= 2 and parts[1] in sig_map:
                        val = parts[0][1:]
                        vid = parts[1]
                        try:
                            hex_val = f"0x{int(val, 2):X}"
                        except:
                            hex_val = val
                        sig_map[vid]["changes"].append((current_t, hex_val))
                elif len(line) >= 2 and line[0] in ["0", "1"]:
                    val = int(line[0])
                    vid = line[1:].strip()
                    if vid in sig_map:
                        sig_map[vid]["changes"].append((current_t, val))

        return list(sig_map.values()), max_t

    def _auto_discover_rtl_files(self, vcd_path):
        """Automatically find respective RTL files by checking filelist.f or scanning project directory."""
        proj_dir = os.path.dirname(vcd_path)
        candidates = []

        # 1. Check for filelist.f in project directory or subdirectories
        possible_filelists = [
            os.path.join(proj_dir, "filelist.f"),
            os.path.join(proj_dir, "filelist_wsl.f"),
            os.path.join(proj_dir, "files.f"),
            os.path.join(proj_dir, "..", "filelist.f"),
            os.path.join(proj_dir, "rtl", "filelist.f"),
        ]

        for fl in possible_filelists:
            if os.path.isfile(fl):
                fl_dir = os.path.dirname(fl)
                with open(fl, "r", encoding="utf-8", errors="ignore") as f:
                    for line in f:
                        line = line.strip()
                        if not line or line.startswith("//") or line.startswith("#") or line.startswith("+"):
                            continue
                        # Resolve path
                        target = os.path.normpath(os.path.join(fl_dir, line))
                        if os.path.isfile(target) and (target.endswith(".v") or target.endswith(".sv")):
                            candidates.append(target)
                if candidates:
                    return candidates

        # 2. If no filelist.f, scan directory and rtl/ folders for .v / .sv files
        search_dirs = [proj_dir, os.path.join(proj_dir, "rtl"), os.path.join(proj_dir, "src")]
        for d in search_dirs:
            if os.path.isdir(d):
                for fname in os.listdir(d):
                    if fname.endswith(".v") or fname.endswith(".sv"):
                        candidates.append(os.path.join(d, fname))

        return candidates

    def _load_rtl_files(self, file_paths):
        self.modules = {}
        for p in file_paths:
            if not os.path.isfile(p):
                continue
            fname = os.path.basename(p)
            with open(p, "r", encoding="utf-8", errors="ignore") as f:
                lines = [ln.rstrip() for ln in f.readlines()]

            # Parse module declaration
            mod_name = os.path.splitext(fname)[0]
            ports = []
            drivers = {}
            loads = {}

            for idx, line in enumerate(lines):
                l_num = idx + 1
                # Find module name
                m_match = re.search(r"\bmodule\s+([A-Za-z0-9_]+)", line)
                if m_match and not line.strip().startswith("//"):
                    mod_name = m_match.group(1)

                # Ports
                if "input" in line and not line.strip().startswith("//"):
                    parts = re.findall(r"\b[A-Za-z0-9_]+(?:\s*\[[^\]]+\])?\b", line)
                    if parts:
                        ports.append(("input", parts[-1].replace(";", "")))
                elif "output" in line and not line.strip().startswith("//"):
                    parts = re.findall(r"\b[A-Za-z0-9_]+(?:\s*\[[^\]]+\])?\b", line)
                    if parts:
                        ports.append(("output", parts[-1].replace(";", "")))

                # Drivers: assign <lhs> = <rhs>
                assign_match = re.search(r"\bassign\s+([A-Za-z0-9_]+(?:\s*\[[^\]]+\])?)\s*=", line)
                if assign_match:
                    lhs = assign_match.group(1).strip()
                    drivers[lhs] = {"line": l_num, "file": fname, "cause": line.strip()}

                # Drivers: <lhs> <= <rhs>
                nblk_match = re.search(r"([A-Za-z0-9_]+(?:\s*\[[^\]]+\])?)\s*<=", line)
                if nblk_match:
                    lhs = nblk_match.group(1).strip()
                    if lhs not in drivers:
                        drivers[lhs] = {"line": l_num, "file": fname, "cause": line.strip()}

            self.modules[mod_name] = {
                "file": fname,
                "full_path": p,
                "parent": None,
                "children": [],
                "ports": ports,
                "lines": lines,
                "drivers": drivers,
                "loads": loads
            }

        # Resolve top-level module (the one with 'top' in name or not instantiated as a child)
        top_cand = next((m for m in self.modules.keys() if "top" in m.lower()), list(self.modules.keys())[0])
        self.current_scope = top_cand

        # Set parent/children hierarchy relationships
        for m_name, m_info in self.modules.items():
            if m_name != self.current_scope:
                m_info["parent"] = self.current_scope
                self.modules[self.current_scope]["children"].append(m_name)

    def _create_fallback_modules_from_vcd(self, vcd_path):
        mod_name = os.path.splitext(os.path.basename(vcd_path))[0]
        lines = [
            f"// Synthesized Scope for Waveform: {os.path.basename(vcd_path)}",
            f"module {mod_name} (",
        ]
        ports = []
        for s in self.signals:
            lines.append(f"    inout wire [{s['width']-1}:0] {s['name']},")
            ports.append(("inout", s["name"]))
        lines.append(");")
        lines.append("    // Trace signals active in waveform window")
        lines.append("endmodule")

        self.modules = {
            mod_name: {
                "file": f"{mod_name}.v",
                "full_path": vcd_path,
                "parent": None,
                "children": [],
                "ports": ports,
                "lines": lines,
                "drivers": {},
                "loads": {}
            }
        }
        self.current_scope = mod_name

    def open_rtl_dialog(self):
        paths = filedialog.askopenfilenames(
            title="Open Verilog RTL Source Files",
            filetypes=[("Verilog Source Files", "*.v *.sv"), ("All Files", "*.*")]
        )
        if paths:
            self._load_rtl_files(list(paths))
            self._populate_hierarchy()
            self._render_rtl()
            messagebox.showinfo("RTL Loaded", f"Loaded {len(paths)} Verilog source files.")

    # --------------------------------------------------------------------------
    # Signal Value & Formatting Utilities
    # --------------------------------------------------------------------------
    def get_signal_raw_val(self, sig_name, t):
        clean = re.sub(r"\[.*\]", "", sig_name)
        sig = next((s for s in self.signals if s["name"].startswith(clean) or s["clean"] == clean), None)
        if not sig or not sig["changes"]:
            return "0"
        val = sig["changes"][0][1]
        for chg in sig["changes"]:
            if chg[0] <= t:
                val = chg[1]
            else:
                break
        return val

    def format_radix(self, val, width):
        if width == 1:
            return "1'b1" if str(val) == "1" else "1'b0"
        try:
            num = int(str(val), 16) if str(val).startswith("0x") else int(str(val))
            if self.radix == "BIN":
                return "b" + bin(num)[2:].zfill(min(width, 16))
            elif self.radix == "DEC":
                return "d" + str(num)
            else:
                return "0x" + hex(num)[2:].upper()
        except:
            return str(val)

    def get_signal_val(self, sig_name, t):
        clean = re.sub(r"\[.*\]", "", sig_name)
        sig = next((s for s in self.signals if s["name"].startswith(clean) or s["clean"] == clean), None)
        raw = self.get_signal_raw_val(sig_name, t)
        width = sig["width"] if sig else 32
        return self.format_radix(raw, width)

    # --------------------------------------------------------------------------
    # Hierarchy, Signals, & RTL Rendering
    # --------------------------------------------------------------------------
    def _populate_hierarchy(self):
        self.hier_tree.delete(*self.hier_tree.get_children())
        for mod_name, mod in self.modules.items():
            parent_id = mod.get("parent") or ""
            text = f"📄 {mod_name} ({mod['file']})"
            self.hier_tree.insert(parent_id, tk.END, iid=mod_name, text=text, open=True)
        if self.current_scope and self.hier_tree.exists(self.current_scope):
            self.hier_tree.selection_set(self.current_scope)

    def _on_scope_select(self, e):
        sel = self.hier_tree.selection()
        if sel:
            self.current_scope = sel[0]
            self._render_rtl()

    def _populate_signals(self, filter_text=""):
        self.sig_tree.delete(*self.sig_tree.get_children())
        ft = filter_text.strip().lower()
        for sig in self.signals:
            if not ft or ft in sig["name"].lower():
                val = self.get_signal_val(sig["name"], self.cursor_c1)
                self.sig_tree.insert("", tk.END, iid=sig["name"], text=sig["name"], values=(val,))
        if self.selected_signal and self.sig_tree.exists(self.selected_signal):
            self.sig_tree.selection_set(self.selected_signal)

    def filter_signals(self, text):
        if text == "Filter signals...":
            text = ""
        self._populate_signals(text)
        self._render_waves()

    def _on_signal_select(self, e):
        sel = self.sig_tree.selection()
        if sel:
            self.selected_signal = sel[0]
            self._update_status()

    def _render_rtl(self):
        mod = self.modules.get(self.current_scope)
        if not mod:
            return
        self.scope_lbl.config(text=f"Scope: {self.current_scope} | File: {mod['file']}")

        # Populate Ports
        self.ports_tree.delete(*self.ports_tree.get_children())
        for p_dir, p_name in mod["ports"]:
            val = self.get_signal_val(p_name, self.cursor_c1)
            self.ports_tree.insert("", tk.END, text=p_name, values=(p_dir, val))

        # Render Lines with In-line Annotations
        self.code_text.delete("1.0", tk.END)
        self.gutter.config(state=tk.NORMAL)
        self.gutter.delete("1.0", tk.END)

        for idx, line in enumerate(mod["lines"]):
            l_num = idx + 1
            self.gutter.insert(tk.END, f"{l_num:>4}\n")

            anno_text = ""
            if self.show_annotation and self.signals:
                for sig in self.signals:
                    clean = sig["clean"]
                    if clean in line and any(k in line for k in ["assign", "input", "output", "reg", "<="]):
                        val = self.get_signal_val(sig["name"], self.cursor_c1)
                        anno_text += f" [={val}]"

            display_line = line
            if anno_text:
                display_line = f"{line:<55}{anno_text}"

            self.code_text.insert(tk.END, display_line + "\n")

        self.gutter.config(state=tk.DISABLED)

    # --------------------------------------------------------------------------
    # Waveform Canvas Rendering
    # --------------------------------------------------------------------------
    def _render_waves(self):
        self.ruler_canvas.delete("all")
        self.wave_canvas.delete("all")

        if not self.signals:
            return

        max_t = self.max_time
        width = max(1200, int(max_t / self.time_per_pixel) + 80)
        visible_signals = [s for s in self.signals if self.sig_tree.exists(s["name"])]
        height = len(visible_signals) * 32

        self.ruler_canvas.config(scrollregion=(0, 0, width, 24))
        self.wave_canvas.config(scrollregion=(0, 0, width, height))

        # Ruler
        step = 100 if self.time_per_pixel > 1.2 else (50 if self.time_per_pixel > 0.5 else 20)
        for t in range(0, int(max_t) + step, step):
            x = t / self.time_per_pixel
            self.ruler_canvas.create_line(x, 12, x, 24, fill="#666")
            self.ruler_canvas.create_text(x + 2, 8, text=f"{t}ns", fill="#aaa", font=("Consolas", 8), anchor=tk.W)

        # Traces
        for idx, sig in enumerate(visible_signals):
            y_top = idx * 32
            y_mid = y_top + 16
            y_bot = y_top + 28

            self.wave_canvas.create_line(0, y_top + 32, width, y_top + 32, fill="#181818")

            if sig["width"] == 1:
                pts = []
                last_y = y_bot
                for chg in sig["changes"]:
                    x = chg[0] / self.time_per_pixel
                    y = y_top + 6 if chg[1] == 1 else y_bot
                    pts.extend([x, last_y, x, y])
                    last_y = y
                pts.extend([width, last_y])
                if len(pts) >= 4:
                    self.wave_canvas.create_line(*pts, fill="#00ff44", width=2)
            else:
                for c_idx, chg in enumerate(sig["changes"]):
                    next_t = sig["changes"][c_idx + 1][0] if c_idx + 1 < len(sig["changes"]) else max_t
                    x1 = chg[0] / self.time_per_pixel
                    x2 = next_t / self.time_per_pixel
                    if x2 > x1 + 2:
                        poly = [x1 + 3, y_top + 6, x2 - 3, y_top + 6, x2, y_mid, x2 - 3, y_bot, x1 + 3, y_bot, x1, y_mid]
                        self.wave_canvas.create_polygon(*poly, fill="#1c1c00", outline="#f0c000")
                        val_str = self.format_radix(chg[1], sig["width"])
                        if x2 - x1 > 35:
                            self.wave_canvas.create_text(x1 + 6, y_mid, text=val_str, fill="#fff", font=("Consolas", 8), anchor=tk.W)

        # Cursor C2 (Cyan)
        c2_x = self.cursor_c2 / self.time_per_pixel
        self.wave_canvas.create_line(c2_x, 0, c2_x, height, fill="#00ffff", width=1, dash=(4, 2))
        self.ruler_canvas.create_rectangle(c2_x - 3, 0, c2_x + 3, 14, fill="#00ffff", outline="")

        # Cursor C1 (Yellow)
        c1_x = self.cursor_c1 / self.time_per_pixel
        self.wave_canvas.create_line(c1_x, 0, c1_x, height, fill="#ffff00", width=2)
        self.ruler_canvas.create_rectangle(c1_x - 3, 10, c1_x + 3, 24, fill="#ffff00", outline="")

    def _on_wave_click(self, e, shift=False):
        if not self.signals:
            return
        x = self.wave_canvas.canvasx(e.x)
        new_t = max(0.0, min(self.max_time, x * self.time_per_pixel))
        if shift:
            self.cursor_c2 = new_t
        else:
            self.cursor_c1 = new_t

        self._update_timing_display()
        self._populate_signals(self.sig_filter_entry.get())
        self._render_rtl()
        self._render_waves()
        self._update_status()

    def _on_wave_drag(self, e):
        if not self.signals:
            return
        x = self.wave_canvas.canvasx(e.x)
        self.cursor_c1 = max(0.0, min(self.max_time, x * self.time_per_pixel))
        self._update_timing_display()
        self._populate_signals(self.sig_filter_entry.get())
        self._render_waves()
        self._update_status()

    def _update_timing_display(self):
        delta = abs(self.cursor_c2 - self.cursor_c1)
        freq = (1000.0 / delta) if delta > 0 else 0.0
        self.time_lbl.config(text=f"C1: {self.cursor_c1:.3f} ns | C2: {self.cursor_c2:.3f} ns | Δ: {delta:.3f} ns ({freq:.1f} MHz)")

    def _update_status(self):
        if self.selected_signal:
            val = self.get_signal_val(self.selected_signal, self.cursor_c1)
            self.stat_sig.config(text=f"Signal: {self.selected_signal}")
            self.stat_val.config(text=f"Value @ C1: {val}")

    # --------------------------------------------------------------------------
    # Verdi Action Features: Backtrace, Load Trace, Cone of Influence
    # --------------------------------------------------------------------------
    def action_backtrace(self):
        if not self.selected_signal or not self.modules:
            messagebox.showinfo("Backtrace", "Please open a waveform and select a signal first.")
            return

        mod = self.modules.get(self.current_scope)
        if not mod:
            return
        clean = re.sub(r"\[.*\]", "", self.selected_signal)
        drv = mod.get("drivers", {}).get(self.selected_signal) or mod.get("drivers", {}).get(clean)

        if not drv:
            for idx, line in enumerate(mod["lines"]):
                if (f"assign {clean}" in line or f"{clean} <=" in line or f"{clean} =" in line) and "input" not in line:
                    drv = {"line": idx + 1, "file": mod["file"], "cause": line.strip()}
                    break

        if drv:
            line_no = drv["line"]
            self.code_text.tag_remove("driver_hit", "1.0", tk.END)
            self.code_text.tag_remove("load_hit", "1.0", tk.END)
            start_idx = f"{line_no}.0"
            end_idx = f"{line_no}.end"
            self.code_text.tag_add("driver_hit", start_idx, end_idx)
            self.code_text.see(start_idx)
            self.stat_drv.config(text=f"🎯 DRIVER: {drv['file']}:{line_no}")
            val = self.get_signal_val(self.selected_signal, self.cursor_c1)
            messagebox.showinfo("Verdi Back-Trace Complete",
                                f"🎯 Signal: {self.selected_signal}\n"
                                f"Driver: {drv['file']} (Line {line_no})\n"
                                f"Expression: {drv['cause']}\n"
                                f"Value @ {self.cursor_c1:.1f} ns: {val}")
        else:
            if mod.get("parent"):
                messagebox.showinfo("Ascending Hierarchy", f"Signal '{self.selected_signal}' is an input port in '{self.current_scope}'.\nAscending to parent scope '{mod['parent']}'...")
                self.nav_hierarchy_up()
                self.action_backtrace()
            else:
                messagebox.showinfo("Driver Found", f"Signal '{self.selected_signal}' is driven at top-level by the testbench environment.")

    def action_trace_load(self):
        if not self.selected_signal or not self.modules:
            messagebox.showinfo("Trace Load", "Please open a waveform and select a signal first.")
            return

        mod = self.modules.get(self.current_scope)
        if not mod:
            return
        clean = re.sub(r"\[.*\]", "", self.selected_signal)
        loads = mod.get("loads", {}).get(clean, [])

        if not loads:
            for idx, line in enumerate(mod["lines"]):
                if clean in line and f"assign {clean}" not in line and "output" not in line:
                    loads.append(idx + 1)

        self.code_text.tag_remove("driver_hit", "1.0", tk.END)
        self.code_text.tag_remove("load_hit", "1.0", tk.END)

        for l_num in loads:
            self.code_text.tag_add("load_hit", f"{l_num}.0", f"{l_num}.end")

        if loads:
            self.code_text.see(f"{loads[0]}.0")

        messagebox.showinfo("Verdi Trace Load (Fanout)",
                            f"⏩ Found {len(loads)} consuming statements for '{self.selected_signal}' in {mod['file']}.\n"
                            f"Lines: {', '.join(map(str, loads))}\n"
                            f"Highlighted in cyan.")

    def action_show_drivers(self):
        if not self.modules:
            return
        mod = self.modules.get(self.current_scope)
        if not mod:
            return
        msg = f"⚡ Drivers in scope [{self.current_scope}]:\n\n"
        for sig_k, d in mod.get("drivers", {}).items():
            val = self.get_signal_val(sig_k, self.cursor_c1)
            msg += f"• {sig_k} = {val}\n  Line {d['line']}: {d['cause']}\n\n"
        messagebox.showinfo("Cone of Influence (Drivers)", msg if mod.get("drivers") else "No drivers recorded in this scope.")

    def nav_hierarchy_up(self):
        if not self.modules or not self.current_scope:
            return
        mod = self.modules.get(self.current_scope)
        if mod and mod.get("parent"):
            self.current_scope = mod["parent"]
            self._populate_hierarchy()
            self._render_rtl()
        else:
            messagebox.showinfo("Hierarchy", "Already at the top root scope.")

    def nav_hierarchy_down(self):
        if not self.modules or not self.current_scope:
            return
        mod = self.modules.get(self.current_scope)
        if mod and mod.get("children"):
            self.current_scope = mod["children"][0]
            self._populate_hierarchy()
            self._render_rtl()
        else:
            messagebox.showinfo("Hierarchy", "No sub-modules found under this scope.")

    def toggle_annotation(self):
        self.show_annotation = not self.show_annotation
        self.btn_anno.config(text="🟢 RTL Values: ON" if self.show_annotation else "⚪ RTL Values: OFF",
                             bg="#d4edda" if self.show_annotation else "#f0ede0")
        self._render_rtl()

    def change_radix(self, new_radix):
        self.radix = new_radix
        self._populate_signals(self.sig_filter_entry.get())
        self._render_rtl()
        self._render_waves()
        self._update_status()

    def zoom_fit(self):
        self.time_per_pixel = max(0.1, self.max_time / 800.0)
        self._render_waves()

    def zoom_in(self):
        self.time_per_pixel = max(0.05, self.time_per_pixel * 0.7)
        self._render_waves()

    def zoom_out(self):
        self.time_per_pixel = self.time_per_pixel * 1.4
        self._render_waves()

    def toggle_dark_theme(self):
        self.dark_mode = not self.dark_mode
        bg_code = "#1e1e1e" if self.dark_mode else "#ffffff"
        fg_code = "#d4d4d4" if self.dark_mode else "#1a1a1a"
        self.code_text.config(bg=bg_code, fg=fg_code)
        self._render_rtl()


if __name__ == "__main__":
    initial_vcd_arg = sys.argv[1] if len(sys.argv) > 1 else None
    app = VcWaveNativeStudio(initial_vcd_arg)
    app.mainloop()
