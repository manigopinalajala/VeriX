# USER GUIDE: HOW TO USE VC_SIM & VC_WAVE

Comprehensive user manual and tutorial for running simulations with **`vc_sim`** and performing interactive waveform/RTL debug with **`vc_wave`**.

---

## 📑 TABLE OF CONTENTS
1. [Core Concepts & Innovations](#1-core-concepts--innovations)
2. [Command Reference: `vc_sim`](#2-command-reference-vc_sim)
3. [Running Simulations (Step-by-Step)](#3-running-simulations-step-by-step)
4. [Using the Standalone GUI: `vc_wave`](#4-using-the-standalone-gui-vc_wave)
5. [Interactive Debugging Workflows](#5-interactive-debugging-workflows)
6. [Complete End-to-End Tutorial (DMA SoC Subsystem)](#6-complete-end-to-end-tutorial-dma-soc-subsystem)

---

## 1. CORE CONCEPTS & INNOVATIONS

### A. Unified Waveform + Embedded RTL Snapshot (Zero-Prompt Workflow)
In conventional EDA tools (like Synopsys VCS + Verdi), after running a simulation you must open the waveform, then navigate dialogs or provide a filelist to tell the viewer where your RTL files live.

In **`vc_sim` + `vc_wave`**:
1. When `vc_sim` runs, it packages all active RTL source files from `filelist.f` into an in-memory JSON snapshot.
2. The snapshot is written into the `.vcd` waveform header using standard IEEE 1364 comments:
   ```vcd
   $comment [VC_WAVE_RTL_SNAPSHOT_BEGIN]
   { "files": [ {"path": "rtl/sync_fifo.v", "content": "..."} ] }
   [VC_WAVE_RTL_SNAPSHOT_END] $end
   ```
3. Opening the `.vcd` in `vc_wave` **instantly unpacks all RTL modules, ports, and hierarchy directly from the wave file**.
4. **Result:** You are never prompted again to locate RTL files.

---

## 2. COMMAND REFERENCE: `vc_sim`

### Checking Version:
```bash
vc_sim -v
vc_sim -version
vc_sim --version
```

### Full Help:
```bash
vc_sim -help
```

### Compilation & Simulation Options:
| Flag | Description |
|---|---|
| `-sverilog` | Enables SystemVerilog IEEE 1800 syntax |
| `+ntb`, `-ntb_opts uvm` | Enables Native Testbench and UVM 1.2 class hierarchy runtime |
| `-f <filelist.f>` | Reads list of source files, include paths, and compile defines |
| `+incdir+<dir>` | Adds search directory for \`include directives |
| `-o <filename>` | Specifies output simulation executable name (default: `simv` / `simv.exe`) |
| `-R` | Runs the compiled simulation immediately after compilation |
| `+UVM_TESTNAME=<name>` | Selects the target UVM testcase to execute |
| `+UVM_VERBOSITY=<lvl>` | Sets verbosity (`UVM_NONE`, `UVM_LOW`, `UVM_MEDIUM`, `UVM_HIGH`, `UVM_DEBUG`) |
| `-l <logfile>` | Redirects simulation output transcript to a log file (default: `simv.log`) |
| `-dump`, `+dump` | Generates standard IEEE 1364 ASCII VCD waveform dump (`dma_subsystem.vcd`) |
| `-fst`, `+fst` | Generates Fast Signal Trace compressed binary waveform (`dump.fst`) |
| `+seed=<val>` | Sets random PRNG seed for randomized testing |

---

## 3. RUNNING SIMULATIONS (STEP-BY-STEP)

### Step 1: Prepare Your Filelist (`filelist.f`)
Create a plain-text file listing your includes and Verilog files:
```text
+incdir+./rtl
./rtl/sync_fifo.v
./rtl/round_robin_arbiter.v
./rtl/crc32_engine.v
./rtl/dual_port_sram.v
./rtl/interrupt_controller.v
./rtl/dma_engine.v
./rtl/axi_lite_slave.v
./rtl/dma_axi_subsystem_top.v
./tb/tb_dma_axi_subsystem.v
```

### Step 2: Compile & Run with One Command
```bash
vc_sim -sverilog -f filelist.f -o simv -R +dump +UVM_TESTNAME=dma_subsystem_full_test
```

### Step 3: Inspect Outputs
* **`simv.log`**: Standard commercial-format simulation transcript with UVM phase messages, functional coverage tables, and testcase pass/fail summaries.
* **`regression_junit.xml`**: CI/CD regression report for Jenkins, GitHub Actions, or GitLab CI.
* **`dma_subsystem.vcd`**: Waveform with embedded RTL ready for instant debugging in `vc_wave`.

---

## 4. USING THE STANDALONE GUI: `vc_wave`

### Launch Methods:

#### On Windows:
* **Option A**: Double-click the **VC_Wave** desktop shortcut.
* **Option B**: Run from Command Prompt / PowerShell:
  ```cmd
  vc_wave
  ```
* **Option C**: Open a waveform file directly:
  ```cmd
  vc_wave dma_subsystem.vcd
  ```

#### On Linux / WSL:
```bash
vc_wave
# or open wave directly:
vc_wave dma_subsystem.vcd
```
*(Note: `verdi` is also supported as a backward-compatible alias).*

---

## 5. INTERACTIVE DEBUGGING WORKFLOWS

Once your `.vcd` waveform is opened in `vc_wave`, the interface presents three synchronized panes:
* **Left Pane**: Hierarchy Tree, Module Port list, and Signal Browser.
* **Center Pane (`nTrace`)**: Full Verilog source code display with line numbers and in-line signal value badges.
* **Right Pane (`nWave`)**: Digital timing waveforms with interactive timeline and dual cursors.

---

### A. Driver Backtracing (`Ctrl+D`)
1. In the **Signal List** or **Waveform canvas**, click on any signal (e.g. `dma_busy`, `irq_out`, `crc_checksum`).
2. Click the **🎯 Backtrace Driver** button on the toolbar or press **`Ctrl+D`**.
3. **What happens:** `vc_wave` scans the RTL, jumps to the driving module, and highlights the exact line (e.g., `assign ...` or non-blocking `<=` assignment) that drove that signal!

---

### B. Trace Load / Fanout (`Ctrl+L`)
1. Select any signal.
2. Click **⏩ Trace Load** on the toolbar or press **`Ctrl+L`**.
3. **What happens:** `vc_wave` lists all downstream sink ports and combinational expressions that consume this signal.

---

### C. Live In-Line RTL Value Annotation
1. Click anywhere on the waveform canvas to position the primary timing cursor (**$C_1$**).
2. Look at the Verilog source code in the **nTrace** pane:
   * Net and register declarations will display green badges showing their exact logic values at that timestamp (e.g., `[dma_busy: 1]`, `[current_addr: 0x04]`).
3. Toggle on/off anytime using the **🟢 RTL Values: ON/OFF** button.

---

### D. Timing Measurements with Dual Cursors ($C_1$ & $C_2$)
1. **Left-Click** anywhere on the waveform canvas to position Cursor 1 ($C_1$).
2. **Shift + Left-Click** to position Cursor 2 ($C_2$).
3. The toolbar automatically calculates and displays:
   * Exact time of $C_1$ (e.g., `210.000 ns`)
   * Exact time of $C_2$ (e.g., `350.000 ns`)
   * Time delta $\Delta t$ (e.g., `140.000 ns`)
   * Equivalent operating frequency (e.g., `7.143 MHz`)

---

### E. Bus Radix Switching
Click the **Radix** dropdown on the toolbar to switch bus representations between:
* **HEX**: Hexadecimal (e.g., `0x8849ED38`)
* **BIN**: Binary (e.g., `10001000010010011110110100111000`)
* **DEC**: Unsigned Decimal

Both the waveform bus traces and the RTL in-line annotations update immediately.

---

### F. Up / Down Hierarchy Navigation
* Click **⬇️ Down** on the toolbar to step down into submodules (`u_sram`, `u_dma_engine`, `u_crc32`).
* Click **⬆️ Up** on the toolbar to navigate back toward top-level SoC root.

---

## 6. COMPLETE END-TO-END TUTORIAL (DMA SOC SUBSYSTEM)

Try the full verification flow right now with the included example:

```bash
# 1. Navigate to the example directory
cd examples/complex_dma_subsystem

# 2. Run simulation and generate waveform
# On Linux / WSL:
make clean compile run

# On Windows:
vc_sim -sverilog -f filelist.f -o simv.exe -R +dump

# 3. Open the unified waveform in VC_Wave
vc_wave dma_subsystem.vcd
```

### What You Will See:
1. All 7 test phases execute with **100% functional coverage** and 0 errors.
2. `vc_wave` launches and automatically reconstructs the entire 9-module hierarchy without asking for any files.
3. You can click on `irq_out` at `350 ns` and press `Ctrl+D` to see the exact interrupt assertion logic in `dma_engine.v`!
