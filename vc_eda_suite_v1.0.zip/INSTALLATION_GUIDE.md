# INSTALLATION GUIDE: VC_SIM & VC_WAVE EDA SUITE

Complete setup and configuration instructions for **Microsoft Windows** and **Linux / WSL** (Ubuntu, Debian, RHEL, CentOS, Rocky Linux, Amazon Linux).

---

## 📦 Package Overview

The **VC_SIM & VC_WAVE EDA Suite** includes:
1. **`vc_sim`**: Native compiled SystemVerilog & UVM 1.2 simulation engine with automated IEEE 1364 waveform dumping.
2. **`vc_wave`** *(formerly Verdi)*: Standalone native desktop waveform viewer (`nWave`) and synchronized RTL source code navigator (`nTrace`).
3. **C++ Simulation Kernel & UVM Library**: Headers under `include/` providing event-driven simulation, functional coverage, and UCDB reporting.
4. **Verified Example Design**: `examples/complex_dma_subsystem` (9-module DMA + AXI4-Lite SoC subsystem).

---

## 🪟 PART 1: WINDOWS INSTALLATION

### System Requirements:
* Windows 10 or Windows 11 (64-bit)
* 4 GB RAM minimum
* C++ compiler (MinGW-w64 `g++` or Visual Studio C++ tools) for compiling simulation models with `vc_sim`
* **Note on `vc_wave.exe`**: It is a standalone 64-bit binary (10.3 MB). **It requires no Python, no Tkinter, and no external runtime on Windows.**

---

### Method A: 1-Click Automated Setup (Recommended)

1. Extract `vc_eda_suite_v1.0.zip` to your chosen directory (for example `C:\eda\vc_eda_suite_v1.0`).
2. Open the extracted folder and double-click:
   ```cmd
   install_windows.bat
   ```
3. The script will:
   * Permanently register the `bin\` directory into your Windows User `PATH` environment variable.
   * Create a **VC_Wave** desktop shortcut on your Windows desktop.
4. Open a **new** Command Prompt or PowerShell and verify:
   ```cmd
   vc_sim -v
   vc_wave
   ```

---

### Method B: PowerShell Setup

Open PowerShell as Administrator in the extracted folder and run:
```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\install_windows.ps1
```

---

### Method C: Manual Windows PATH Configuration

If you prefer not to use scripts:
1. Move the extracted folder to a permanent directory, e.g.:
   `C:\tools\vc_eda_suite_v1.0`
2. Press `Win + R`, type `sysdm.cpl`, and press **Enter**.
3. Go to the **Advanced** tab ➔ Click **Environment Variables**.
4. Under **User variables**, select `Path` ➔ Click **Edit...**.
5. Click **New** ➔ Paste the path to the `bin` directory:
   ```
   C:\tools\vc_eda_suite_v1.0\bin
   ```
6. Click **OK** on all windows.
7. Open a new Command Prompt and confirm:
   ```cmd
   where vc_sim
   where vc_wave
   ```

---

### Windows Uninstallation:
To remove the tools from your PATH and delete the desktop shortcut, run:
```cmd
uninstall_windows.bat
```

---

## 🐧 PART 2: LINUX & WSL INSTALLATION

### Supported Distributions:
* Ubuntu 20.04 / 22.04 / 24.04 LTS
* Debian 11 / 12
* RHEL / CentOS / Rocky Linux / AlmaLinux 8 & 9
* Amazon Linux 2 & 2023 (AWS EC2)
* Windows Subsystem for Linux (WSL / WSL2)

---

### Step 1: Install System Prerequisites

Open your terminal and install the C++ compiler and Python Tkinter GUI library for your distribution:

#### On Ubuntu / Debian / WSL:
```bash
sudo apt update
sudo apt install -y build-essential g++ python3 python3-tk
```

#### On RHEL / CentOS / Rocky Linux / AlmaLinux:
```bash
sudo dnf install -y gcc-c++ make python3 python3-tkinter
```

#### On Amazon Linux 2023 (AWS EC2):
```bash
sudo dnf install -y gcc-c++ make python3 python3-tkinter
```

#### On Amazon Linux 2 (AWS EC2):
```bash
sudo yum install -y gcc-c++ make python3 python3-tkinter
```

---

### Step 2: Run the Automated Linux Installer

1. Extract the package:
   ```bash
   unzip vc_eda_suite_v1.0.zip -d vc_eda_suite_v1.0
   cd vc_eda_suite_v1.0
   ```
2. Make the installer executable and run it:
   ```bash
   chmod +x install_linux.sh
   ./install_linux.sh
   ```
   * *If run with `sudo`*: Installs globally into `/opt/vc_eda_suite` and creates symlinks in `/usr/local/bin` (`/usr/local/bin/vc_sim` and `/usr/local/bin/vc_wave`).
   * *If run as normal user*: Installs into `~/.local/share/vc_eda_suite` and links into `~/.local/bin/`.

---

### Step 3: Verify Linux Installation

Close and reopen your terminal (or run `source ~/.bashrc`), then run:

```bash
# Verify vc_sim compiler version
vc_sim -v

# Verify vc_sim help
vc_sim -help

# Verify vc_wave launcher
which vc_wave
```

---

### 🌐 Special Note for Remote Headless Servers (AWS EC2 / Cloud VM)

If running on a remote cloud Linux server without a physical monitor:

1. **Option 1: SSH with X11 Forwarding (To see the GUI from EC2 on your PC)**:
   * Start an X-server on your Windows PC (such as **MobaXterm** or **VcXsrv**).
   * SSH to EC2 with the `-X` flag:
     ```bash
     ssh -X ec2-user@<your-ec2-ip-address>
     ```
   * Run:
     ```bash
     vc_wave
     ```

2. **Option 2: Best-Practice Local Viewing (Zero Latency)**:
   * Run your high-performance simulations on EC2:
     ```bash
     vc_sim -sverilog -f filelist.f -o simv -R +dump
     ```
   * Download the generated `dma_subsystem.vcd` to your local PC.
   * Open it locally with `vc_wave.exe` on Windows. Because the RTL is embedded inside the waveform, it opens instantly without cloud network lag!

---

## 🔧 Environment Variables Summary

| Variable | Description | Example |
|---|---|---|
| `PATH` | Must include the `bin/` directory | `C:\eda\vc_eda_suite_v1.0\bin` or `/usr/local/bin` |
| `VC_EDA_HOME` | *(Optional)* Base directory of the suite | `/opt/vc_eda_suite` or `C:\eda\vc_eda_suite_v1.0` |
| `DISPLAY` | *(Linux only)* X11 display server address | `localhost:10.0` or `:0` |
