// =============================================================================
// File: axi_lite_slave.v
// Module: axi_lite_slave
// Description: Standard AXI4-Lite Slave Interface with Register Bank and
//              SRAM Port A bus bridge.
// =============================================================================

`timescale 1ns / 1ps

module axi_lite_slave (
    input  wire        aclk,
    input  wire        aresetn,
    
    // AXI4-Lite Write Address Channel
    input  wire [31:0] s_axi_awaddr,
    input  wire        s_axi_awvalid,
    output reg         s_axi_awready,
    
    // AXI4-Lite Write Data Channel
    input  wire [31:0] s_axi_wdata,
    input  wire [3:0]  s_axi_wstrb,
    input  wire        s_axi_wvalid,
    output reg         s_axi_wready,
    
    // AXI4-Lite Write Response Channel
    output reg  [1:0]  s_axi_bresp,
    output reg         s_axi_bvalid,
    input  wire        s_axi_bready,
    
    // AXI4-Lite Read Address Channel
    input  wire [31:0] s_axi_araddr,
    input  wire        s_axi_arvalid,
    output reg         s_axi_arready,
    
    // AXI4-Lite Read Data Channel
    output reg  [31:0] s_axi_rdata,
    output reg  [1:0]  s_axi_rresp,
    output reg         s_axi_rvalid,
    input  wire        s_axi_rready,
    
    // Subsystem Control/Status Registers
    output reg         reg_dma_start,
    output reg         reg_dma_abort,
    output reg  [7:0]  reg_src_addr,
    output reg  [7:0]  reg_dst_addr,
    output reg  [7:0]  reg_xfer_len,
    output reg         reg_crc_init,
    output reg  [31:0] reg_crc_seed,
    output reg  [3:0]  reg_imr_val,
    output reg         reg_imr_we,
    output reg  [3:0]  reg_isr_clr_val,
    output reg         reg_isr_clr_we,
    
    // Status Inputs from Submodules
    input  wire        dma_busy,
    input  wire        dma_done,
    input  wire        dma_err,
    input  wire [7:0]  dma_words_done,
    input  wire [31:0] crc_checksum,
    input  wire [3:0]  int_imr,
    input  wire [3:0]  int_isr,
    input  wire [3:0]  int_ipr,
    input  wire        fifo_full,
    input  wire        fifo_empty,
    input  wire [4:0]  fifo_occupancy,
    
    // Direct SRAM Access via Port A
    output reg         sram_en_a,
    output reg  [3:0]  sram_we_a,
    output reg  [7:0]  sram_addr_a,
    output reg  [31:0] sram_wdata_a,
    input  wire [31:0] sram_rdata_a
);

    // Register Offsets
    localparam ADDR_CTRL    = 8'h00; // [0]: Start, [1]: Abort, [2]: CRC Init
    localparam ADDR_STATUS  = 8'h04; // [0]: Busy, [1]: Done, [2]: Error, [3]: FIFO Full, [4]: FIFO Empty
    localparam ADDR_SRC     = 8'h08; // Source SRAM Word Address [7:0]
    localparam ADDR_LEN     = 8'h0C; // Transfer Length in Words [7:0]
    localparam ADDR_CRC     = 8'h10; // Read: Computed CRC32 | Write: CRC Seed
    localparam ADDR_IMR     = 8'h14; // Interrupt Mask Register
    localparam ADDR_ISR     = 8'h18; // Interrupt Status / Write-1-to-Clear
    localparam ADDR_FIFO    = 8'h1C; // FIFO Status & Occupancy
    localparam SRAM_BASE    = 32'h0000_1000; // Base address for direct SRAM access

    // Latched write address and data
    reg [31:0] axi_awaddr_latched;
    reg [31:0] axi_wdata_latched;
    reg [3:0]  axi_wstrb_latched;
    reg        aw_en;

    // AXI4-Lite Write Channel Handshake
    always @(posedge aclk or negedge aresetn) begin
        if (!aresetn) begin
            s_axi_awready      <= 1'b0;
            s_axi_wready       <= 1'b0;
            s_axi_bvalid       <= 1'b0;
            s_axi_bresp        <= 2'b00; // OKAY
            aw_en              <= 1'b1;
            axi_awaddr_latched <= 32'd0;
            axi_wdata_latched  <= 32'd0;
            axi_wstrb_latched  <= 4'd0;
            
            reg_dma_start      <= 1'b0;
            reg_dma_abort      <= 1'b0;
            reg_crc_init       <= 1'b0;
            reg_src_addr       <= 8'd0;
            reg_dst_addr       <= 8'd0;
            reg_xfer_len       <= 8'd0;
            reg_crc_seed       <= 32'hFFFFFFFF;
            reg_imr_val        <= 4'b0000;
            reg_imr_we         <= 1'b0;
            reg_isr_clr_val    <= 4'b0000;
            reg_isr_clr_we     <= 1'b0;

            sram_en_a          <= 1'b0;
            sram_we_a          <= 4'b0000;
            sram_addr_a        <= 8'd0;
            sram_wdata_a       <= 32'd0;
        end else begin
            reg_dma_start   <= 1'b0;
            reg_dma_abort   <= 1'b0;
            reg_crc_init    <= 1'b0;
            reg_imr_we      <= 1'b0;
            reg_isr_clr_we  <= 1'b0;
            sram_en_a       <= 1'b0;
            sram_we_a       <= 4'b0000;

            // AWREADY generation
            if (~s_axi_awready && s_axi_awvalid && s_axi_wvalid && aw_en) begin
                s_axi_awready      <= 1'b1;
                s_axi_wready       <= 1'b1;
                aw_en              <= 1'b0;
                axi_awaddr_latched <= s_axi_awaddr;
                axi_wdata_latched  <= s_axi_wdata;
                axi_wstrb_latched  <= s_axi_wstrb;
            end else begin
                s_axi_awready <= 1'b0;
                s_axi_wready  <= 1'b0;
            end

            // Write Execution
            if (s_axi_awready && s_axi_wready) begin
                s_axi_bvalid <= 1'b1;
                s_axi_bresp  <= 2'b00; // OKAY

                // Check if writing to SRAM or Registers
                if (axi_awaddr_latched >= SRAM_BASE && axi_awaddr_latched < (SRAM_BASE + 32'h400)) begin
                    // Direct SRAM Port A write
                    sram_en_a    <= 1'b1;
                    sram_we_a    <= axi_wstrb_latched;
                    sram_addr_a  <= axi_awaddr_latched[9:2];
                    sram_wdata_a <= axi_wdata_latched;
                end else begin
                    // Register write
                    case (axi_awaddr_latched[7:0])
                        ADDR_CTRL: begin
                            reg_dma_start <= axi_wdata_latched[0];
                            reg_dma_abort <= axi_wdata_latched[1];
                            reg_crc_init  <= axi_wdata_latched[2];
                        end
                        ADDR_SRC:  reg_src_addr <= axi_wdata_latched[7:0];
                        ADDR_LEN:  reg_xfer_len <= axi_wdata_latched[7:0];
                        ADDR_CRC:  reg_crc_seed <= axi_wdata_latched;
                        ADDR_IMR: begin
                            reg_imr_val <= axi_wdata_latched[3:0];
                            reg_imr_we  <= 1'b1;
                        end
                        ADDR_ISR: begin
                            reg_isr_clr_val <= axi_wdata_latched[3:0];
                            reg_isr_clr_we  <= 1'b1;
                        end
                    endcase
                end
            end

            if (s_axi_bvalid && s_axi_bready) begin
                s_axi_bvalid <= 1'b0;
                aw_en        <= 1'b1;
            end
        end
    end

    // AXI4-Lite Read Channel Handshake
    reg [31:0] axi_araddr_latched;
    always @(posedge aclk or negedge aresetn) begin
        if (!resetn) begin
            s_axi_arready <= 1'b0;
            s_axi_rvalid  <= 1'b0;
            s_axi_rresp   <= 2'b00;
            s_axi_rdata   <= 32'd0;
        end else begin
            if (~s_axi_arready && s_axi_arvalid) begin
                s_axi_arready      <= 1'b1;
                axi_araddr_latched <= s_axi_araddr;
            end else begin
                s_axi_arready <= 1'b0;
            end

            if (s_axi_arready) begin
                s_axi_rvalid <= 1'b1;
                s_axi_rresp  <= 2'b00; // OKAY

                if (axi_araddr_latched >= SRAM_BASE && axi_araddr_latched < (SRAM_BASE + 32'h400)) begin
                    s_axi_rdata <= sram_rdata_a;
                end else begin
                    case (axi_araddr_latched[7:0])
                        ADDR_CTRL:   s_axi_rdata <= 32'hA5A5_0000;
                        ADDR_STATUS: s_axi_rdata <= {16'd0, dma_words_done, 3'd0, fifo_empty, fifo_full, dma_err, dma_done, dma_busy};
                        ADDR_SRC:    s_axi_rdata <= {24'd0, reg_src_addr};
                        ADDR_LEN:    s_axi_rdata <= {24'd0, reg_xfer_len};
                        ADDR_CRC:    s_axi_rdata <= crc_checksum;
                        ADDR_IMR:    s_axi_rdata <= {28'd0, int_imr};
                        ADDR_ISR:    s_axi_rdata <= {24'd0, int_ipr, int_isr};
                        ADDR_FIFO:   s_axi_rdata <= {27'd0, fifo_occupancy};
                        default:     s_axi_rdata <= 32'hDEAD_BEEF;
                    endcase
                end
            end

            if (s_axi_rvalid && s_axi_rready) begin
                s_axi_rvalid <= 1'b0;
            end
        end
    end

endmodule
